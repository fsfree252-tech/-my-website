import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { BottomNav, TabType } from './components/BottomNav';
import { HomeTab } from './components/HomeTab';
import { ExploreTab } from './components/ExploreTab';
import { PublishTab } from './components/PublishTab';
import { ActivityTab } from './components/ActivityTab';
import { ProfileTab } from './components/ProfileTab';
import { ShareModal } from './components/ShareModal';
import { LinkDetailsModal } from './components/LinkDetailsModal';
import { ReportModal } from './components/ReportModal';
import { AdminPortal } from './components/AdminPortal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import { ensureAnonymousAuth } from './lib/firebase';
import {
  fetchLinks,
  fetchUserLinks,
  recordClick,
  deleteLink,
  getAppSettings
} from './services/linkService';
import { LinkItem, UserActivity, AppSettings } from './types';
import { Sparkles, AlertOctagon } from 'lucide-react';

export default function App() {
  const isOnline = useOnlineStatus();
  const [currentUid, setCurrentUid] = useState<string>('');
  const [currentTab, setCurrentTab] = useState<TabType>('home');
  const [links, setLinks] = useState<LinkItem[]>([]);
  const [userLinks, setUserLinks] = useState<LinkItem[]>([]);
  const [userActivities, setUserActivities] = useState<UserActivity[]>([]);
  const [settings, setSettings] = useState<AppSettings>({
    adsEnabled: true,
    publishingEnabled: true,
    maintenanceMode: false
  });

  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  // Modals state
  const [shareTargetLink, setShareTargetLink] = useState<LinkItem | null>(null);
  const [detailsTargetLink, setDetailsTargetLink] = useState<LinkItem | null>(null);
  const [reportTargetLink, setReportTargetLink] = useState<LinkItem | null>(null);
  const [deleteCandidate, setDeleteCandidate] = useState<LinkItem | null>(null);
  const [showAdminPortal, setShowAdminPortal] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Load activities from persistent local cache
  const loadLocalActivities = () => {
    try {
      const stored = localStorage.getItem('vip_user_activities');
      if (stored) {
        setUserActivities(JSON.parse(stored));
      }
    } catch {
      // Handled
    }
  };

  const addLocalActivity = (activity: Omit<UserActivity, 'id' | 'timestamp'>) => {
    const newAct: UserActivity = {
      ...activity,
      id: 'act_' + Date.now(),
      timestamp: Date.now()
    };
    setUserActivities((prev) => {
      const updated = [newAct, ...prev].slice(0, 50);
      try {
        localStorage.setItem('vip_user_activities', JSON.stringify(updated));
      } catch {
        // Handled
      }
      return updated;
    });
  };

  // Refresh links and user content
  const loadContent = useCallback(async (uid?: string) => {
    try {
      const allLinks = await fetchLinks();
      setLinks(allLinks);

      const targetUid = uid || currentUid;
      if (targetUid) {
        const myItems = await fetchUserLinks(targetUid);
        setUserLinks(myItems);
      }

      const appSettings = await getAppSettings();
      setSettings(appSettings);
    } catch {
      // Offline fallback
    } finally {
      setLoading(false);
    }
  }, [currentUid]);

  // Initial Firebase Anonymous Auth & Data Load
  useEffect(() => {
    let isMounted = true;

    async function init() {
      loadLocalActivities();
      try {
        const user = await ensureAnonymousAuth();
        if (isMounted) {
          setCurrentUid(user.uid);
          await loadContent(user.uid);
        }
      } catch {
        if (isMounted) {
          setLoading(false);
        }
      }
    }

    init();
    return () => {
      isMounted = false;
    };
  }, [loadContent]);

  // Open Link Handler
  const handleOpenLink = async (link: LinkItem) => {
    // Record click count atomically
    recordClick(link.id);

    // Update local state count
    setLinks((prev) =>
      prev.map((l) => (l.id === link.id ? { ...l, clickCount: (l.clickCount || 0) + 1 } : l))
    );

    addLocalActivity({
      type: 'open',
      linkId: link.id,
      linkTitle: link.title,
      platform: link.platform
    });

    // Launch WhatsApp / Telegram
    window.open(link.url, '_blank');
  };

  // Share Completed Handler
  const handleShareRecorded = (linkId: string) => {
    setLinks((prev) =>
      prev.map((l) => (l.id === linkId ? { ...l, shareCount: (l.shareCount || 0) + 1 } : l))
    );

    const target = links.find((l) => l.id === linkId);
    if (target) {
      addLocalActivity({
        type: 'share',
        linkId: target.id,
        linkTitle: target.title,
        platform: target.platform
      });
    }
  };

  // Delete Link Handler with Confirmation
  const confirmDeleteLink = async () => {
    if (!deleteCandidate) return;

    const res = await deleteLink(
      deleteCandidate.id,
      deleteCandidate.publisherUid,
      currentUid,
      isAdmin
    );

    if (res.success) {
      showToast('Link deleted successfully');
      setLinks((prev) => prev.filter((l) => l.id !== deleteCandidate.id));
      setUserLinks((prev) => prev.filter((l) => l.id !== deleteCandidate.id));
      setDeleteCandidate(null);
    } else {
      showToast(res.error || 'Failed to delete link');
    }
  };

  return (
    <div className="min-h-screen bg-[#05070C] text-white flex flex-col font-sans selection:bg-[#00E676]/30">
      {/* Offline Toast Banner */}
      <OfflineIndicator isOnline={isOnline} />

      {/* App Header */}
      <Header
        onOpenSearch={() => setCurrentTab('explore')}
        onOpenAdmin={() => setShowAdminPortal(true)}
        isAdmin={isAdmin}
        isOnline={isOnline}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-18 left-1/2 -translate-x-1/2 z-50 bg-[#121824] border border-white/[0.12] text-white text-xs font-semibold py-2.5 px-4 rounded-2xl shadow-2xl flex items-center gap-2 animate-in fade-in zoom-in-95">
          <Sparkles className="w-3.5 h-3.5 text-[#00E676]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Container */}
      <main className="flex-1 w-full max-w-md mx-auto px-4 pt-3">
        {/* Maintenance Mode Banner */}
        {settings.maintenanceMode && !isAdmin && (
          <div className="mb-4 bg-amber-500/15 border border-amber-500/30 rounded-2xl p-4 flex items-center gap-3">
            <AlertOctagon className="w-6 h-6 text-amber-400 shrink-0" />
            <div>
              <p className="text-xs font-bold text-amber-300">Maintenance Active</p>
              <p className="text-[11px] text-[#AAB4C3]">
                VIP Share is undergoing scheduled optimizations.
              </p>
            </div>
          </div>
        )}

        {/* Loading Skeleton */}
        {loading ? (
          <div className="flex flex-col gap-3 py-6">
            <div className="h-10 bg-white/[0.04] rounded-2xl animate-pulse" />
            <div className="h-32 bg-white/[0.04] rounded-3xl animate-pulse" />
            <div className="h-28 bg-white/[0.04] rounded-2xl animate-pulse" />
            <div className="h-28 bg-white/[0.04] rounded-2xl animate-pulse" />
          </div>
        ) : (
          <>
            {currentTab === 'home' && (
              <HomeTab
                links={links}
                currentUid={currentUid}
                isAdmin={isAdmin}
                adsEnabled={settings.adsEnabled}
                onOpen={handleOpenLink}
                onShare={(l) => setShareTargetLink(l)}
                onDetails={(l) => setDetailsTargetLink(l)}
                onReport={(l) => setReportTargetLink(l)}
                onDelete={(l) => setDeleteCandidate(l)}
                onNavigatePublish={() => setCurrentTab('publish')}
              />
            )}

            {currentTab === 'explore' && (
              <ExploreTab
                links={links}
                currentUid={currentUid}
                isAdmin={isAdmin}
                onOpen={handleOpenLink}
                onShare={(l) => setShareTargetLink(l)}
                onDetails={(l) => setDetailsTargetLink(l)}
                onReport={(l) => setReportTargetLink(l)}
                onDelete={(l) => setDeleteCandidate(l)}
              />
            )}

            {currentTab === 'publish' && (
              <PublishTab
                currentUid={currentUid}
                publishingEnabled={settings.publishingEnabled}
                onSuccess={() => {
                  loadContent();
                  setCurrentTab('home');
                  showToast('Link published');
                }}
                onCancel={() => setCurrentTab('home')}
              />
            )}

            {currentTab === 'activity' && (
              <ActivityTab
                activities={userActivities}
                userLinks={userLinks}
                onSelectLink={(linkId) => {
                  const item = links.find((l) => l.id === linkId);
                  if (item) setDetailsTargetLink(item);
                }}
                onNavigatePublish={() => setCurrentTab('publish')}
              />
            )}

            {currentTab === 'profile' && (
              <ProfileTab
                currentUid={currentUid}
                userLinks={userLinks}
                isAdmin={isAdmin}
                onOpenAdmin={() => setShowAdminPortal(true)}
                onOpenLink={handleOpenLink}
                onDeleteLink={(l) => setDeleteCandidate(l)}
                onNavigatePublish={() => setCurrentTab('publish')}
              />
            )}
          </>
        )}
      </main>

      {/* Share Modal */}
      <ShareModal
        link={shareTargetLink}
        currentUid={currentUid}
        onClose={() => setShareTargetLink(null)}
        onShareRecorded={handleShareRecorded}
      />

      {/* Details Modal */}
      <LinkDetailsModal
        link={detailsTargetLink}
        onClose={() => setDetailsTargetLink(null)}
        onOpen={handleOpenLink}
        onShare={(l) => setShareTargetLink(l)}
        onReport={(l) => setReportTargetLink(l)}
      />

      {/* Report Modal */}
      <ReportModal
        link={reportTargetLink}
        currentUid={currentUid}
        onClose={() => setReportTargetLink(null)}
      />

      {/* Delete Confirmation Modal */}
      {deleteCandidate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-[#0D1118] border border-white/[0.12] rounded-3xl p-5 shadow-2xl flex flex-col gap-3">
            <h3 className="text-white font-bold text-base">Delete Link?</h3>
            <p className="text-xs text-[#AAB4C3] leading-relaxed">
              Are you sure you want to delete <span className="text-white font-medium">"{deleteCandidate.title}"</span>? This action cannot be undone.
            </p>
            <div className="flex items-center gap-2 mt-2">
              <button
                onClick={() => setDeleteCandidate(null)}
                className="flex-1 py-2.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-[#AAB4C3] text-xs font-semibold tap-bounce transition"
              >
                Cancel
              </button>
              <button
                onClick={confirmDeleteLink}
                className="flex-1 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-bold tap-bounce transition shadow-lg shadow-rose-500/20"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admin Portal Modal */}
      <AdminPortal
        isOpen={showAdminPortal}
        onClose={() => setShowAdminPortal(false)}
        links={links}
        currentUid={currentUid}
        isAdmin={isAdmin}
        onAdminAuthSuccess={() => setIsAdmin(true)}
        onRefreshData={loadContent}
      />

      {/* Samsung-style Bottom Navigation */}
      <BottomNav currentTab={currentTab} onTabChange={setCurrentTab} />
    </div>
  );
}
