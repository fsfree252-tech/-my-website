import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInAnonymously,
  onAuthStateChanged,
  User
} from 'firebase/auth';
import {
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  getFirestore,
  Firestore
} from 'firebase/firestore';
import { getAnalytics, isSupported as isAnalyticsSupported } from 'firebase/analytics';

export const firebaseConfig = {
  apiKey: "AIzaSyBVhE0vAy7flIoJPddFsEuM6RgseFhoh5w",
  authDomain: "apk-market-e18f9.firebaseapp.com",
  databaseURL: "https://apk-market-e18f9-default-rtdb.firebaseio.com",
  projectId: "apk-market-e18f9",
  storageBucket: "apk-market-e18f9.firebasestorage.app",
  messagingSenderId: "346367817062",
  appId: "1:346367817062:web:cc1a7521bc8074956844a7",
  measurementId: "G-2TK8KN9KSR"
};

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

export const auth = getAuth(app);

let dbInstance: Firestore;
try {
  dbInstance = initializeFirestore(app, {
    localCache: persistentLocalCache({
      tabManager: persistentMultipleTabManager()
    })
  });
} catch {
  dbInstance = getFirestore(app);
}

export const db = dbInstance;

// Analytics initialization (browser only)
if (typeof window !== 'undefined') {
  isAnalyticsSupported().then((supported) => {
    if (supported) {
      try {
        getAnalytics(app);
      } catch {
        // Analytics suppression in preview
      }
    }
  });
}

/**
 * Ensures the visitor is authenticated anonymously on startup.
 * Returns the active user.
 */
export async function ensureAnonymousAuth(): Promise<User> {
  if (auth.currentUser) {
    return auth.currentUser;
  }

  return new Promise((resolve) => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        unsubscribe();
        resolve(user);
      } else {
        try {
          const cred = await signInAnonymously(auth);
          unsubscribe();
          resolve(cred.user);
        } catch {
          // If network is offline, resolve with existing cache or synthetic UID
          unsubscribe();
          resolve({ uid: 'offline_user' } as unknown as User);
        }
      }
    });
  });
}
