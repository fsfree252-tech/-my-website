import React from 'react';
import { Home, Compass, Plus, Activity, User } from 'lucide-react';

export type TabType = 'home' | 'explore' | 'publish' | 'activity' | 'profile';

interface BottomNavProps {
  currentTab: TabType;
  onTabChange: (tab: TabType) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentTab, onTabChange }) => {
  const tabs = [
    { id: 'home' as TabType, label: 'Home', icon: Home },
    { id: 'explore' as TabType, label: 'Explore', icon: Compass },
    { id: 'publish' as TabType, label: 'Publish', icon: Plus, isAction: true },
    { id: 'activity' as TabType, label: 'Activity', icon: Activity },
    { id: 'profile' as TabType, label: 'Profile', icon: User }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#070B12]/95 backdrop-blur-2xl border-t border-white/[0.08] pb-[max(env(safe-area-inset-bottom),8px)] pt-2 shadow-2xl">
      <div className="max-w-md mx-auto px-4 flex items-center justify-between">
        {tabs.map((tab) => {
          const isActive = currentTab === tab.id;
          const Icon = tab.icon;

          if (tab.isAction) {
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className="flex flex-col items-center justify-center -mt-5 tap-bounce group focus:outline-none"
                aria-label="Publish Link"
              >
                <div
                  className={`w-13 h-13 rounded-2xl flex items-center justify-center shadow-lg transition-transform duration-200 ${
                    isActive
                      ? 'bg-gradient-to-tr from-[#00E676] to-[#2196F3] shadow-[#00E676]/30 scale-105'
                      : 'bg-gradient-to-tr from-[#00E676] to-[#00B0FF] shadow-[#00E676]/20 group-hover:scale-105'
                  }`}
                >
                  <Plus className="w-6 h-6 text-[#05070C] stroke-[3]" />
                </div>
                <span className={`text-[11px] font-semibold mt-1 transition-colors ${
                  isActive ? 'text-[#00E676]' : 'text-[#AAB4C3]'
                }`}>
                  {tab.label}
                </span>
              </button>
            );
          }

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className="flex-1 flex flex-col items-center justify-center py-1 tap-bounce group focus:outline-none relative"
              aria-label={tab.label}
            >
              <div className="relative flex items-center justify-center">
                <Icon
                  className={`w-5 h-5 transition-colors duration-200 ${
                    isActive
                      ? 'text-[#00E676]'
                      : 'text-[#AAB4C3] group-hover:text-white'
                  }`}
                />
                {isActive && (
                  <span className="absolute -bottom-1.5 w-1 h-1 rounded-full bg-[#00E676] shadow-sm shadow-[#00E676]" />
                )}
              </div>
              <span
                className={`text-[11px] font-medium mt-1 transition-colors duration-200 ${
                  isActive ? 'text-white font-semibold' : 'text-[#AAB4C3]'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
