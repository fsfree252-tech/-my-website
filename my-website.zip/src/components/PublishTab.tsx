import React, { useState } from 'react';
import {
  PlusCircle,
  Users,
  Send,
  AlertCircle,
  CheckCircle,
  Link as LinkIcon
} from 'lucide-react';
import { PlatformType, LinkKind } from '../types';
import {
  CATEGORIES,
  publishLink,
  validateUrl
} from '../services/linkService';

interface PublishTabProps {
  currentUid: string;
  publishingEnabled: boolean;
  onSuccess: () => void;
  onCancel: () => void;
}

export const PublishTab: React.FC<PublishTabProps> = ({
  currentUid,
  publishingEnabled,
  onSuccess,
  onCancel
}) => {
  const [platform, setPlatform] = useState<PlatformType>('whatsapp');
  const [linkType, setLinkType] = useState<LinkKind>('group');
  const [url, setUrl] = useState('');
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<string>('Technology');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    setErrorMessage(null);
    setSuccessNotice(null);

    if (!publishingEnabled) {
      setErrorMessage('Link publishing is temporarily paused by system administration.');
      return;
    }

    // Client URL format validation
    const validation = validateUrl(url, platform);
    if (!validation.valid) {
      setErrorMessage(validation.error || 'Invalid URL format');
      return;
    }

    if (!title.trim() || title.trim().length < 3) {
      setErrorMessage('Please provide a title with at least 3 characters');
      return;
    }

    setSubmitting(true);

    try {
      const res = await publishLink({
        platform,
        linkType,
        url: url.trim(),
        title: title.trim(),
        description: description.trim(),
        category,
        publisherUid: currentUid
      });

      if (res.success) {
        setSuccessNotice('Link published successfully');
        setUrl('');
        setTitle('');
        setDescription('');
        setTimeout(() => {
          onSuccess();
        }, 1200);
      } else {
        setErrorMessage(res.error || 'Failed to publish link');
      }
    } catch {
      setErrorMessage('An unexpected error occurred. Try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col gap-4 pb-24">
      {/* Header */}
      <div className="bg-[#0D1118] border border-white/[0.08] rounded-3xl p-5 shadow-lg">
        <div className="flex items-center gap-2.5 mb-1">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#00E676] to-[#2196F3] flex items-center justify-center text-[#05070C]">
            <PlusCircle className="w-5 h-5 stroke-[2.5]" />
          </div>
          <h2 className="text-white font-bold text-lg leading-tight">
            Publish Link
          </h2>
        </div>
        <p className="text-xs text-[#AAB4C3]">
          Submit a verified WhatsApp or Telegram community link.
        </p>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        {/* Platform Selection */}
        <div className="bg-[#0D1118] border border-white/[0.08] rounded-3xl p-4">
          <label className="text-xs font-semibold text-[#AAB4C3] block mb-2.5">
            Select Platform
          </label>
          <div className="grid grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={() => {
                setPlatform('whatsapp');
                if (linkType === 'channel') setLinkType('group');
              }}
              className={`p-3 rounded-2xl flex items-center gap-2.5 border transition tap-bounce ${
                platform === 'whatsapp'
                  ? 'bg-[#00E676]/15 border-[#00E676] text-white shadow-sm'
                  : 'bg-white/[0.03] border-white/[0.08] text-[#AAB4C3] hover:text-white'
              }`}
            >
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                platform === 'whatsapp' ? 'bg-[#00E676] text-[#05070C]' : 'bg-white/[0.08]'
              }`}>
                <Users className="w-4 h-4 stroke-[2.5]" />
              </div>
              <div className="text-left">
                <div className="text-xs font-bold">WhatsApp</div>
                <div className="text-[10px] text-[#AAB4C3]">Group or Community</div>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setPlatform('telegram')}
              className={`p-3 rounded-2xl flex items-center gap-2.5 border transition tap-bounce ${
                platform === 'telegram'
                  ? 'bg-[#2196F3]/15 border-[#2196F3] text-white shadow-sm'
                  : 'bg-white/[0.03] border-white/[0.08] text-[#AAB4C3] hover:text-white'
              }`}
            >
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                platform === 'telegram' ? 'bg-[#2196F3] text-white' : 'bg-white/[0.08]'
              }`}>
                <Send className="w-4 h-4 stroke-[2.5]" />
              </div>
              <div className="text-left">
                <div className="text-xs font-bold">Telegram</div>
                <div className="text-[10px] text-[#AAB4C3]">Group or Channel</div>
              </div>
            </button>
          </div>

          {/* Format / Type Selection */}
          <div className="mt-3 pt-3 border-t border-white/[0.06] flex items-center justify-between">
            <span className="text-xs text-[#AAB4C3]">Format</span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setLinkType('group')}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition ${
                  linkType === 'group'
                    ? 'bg-white/[0.15] text-white font-semibold'
                    : 'text-[#AAB4C3]'
                }`}
              >
                Group
              </button>
              {platform === 'telegram' ? (
                <button
                  type="button"
                  onClick={() => setLinkType('channel')}
                  className={`px-3 py-1 rounded-lg text-xs font-medium transition ${
                    linkType === 'channel'
                      ? 'bg-white/[0.15] text-white font-semibold'
                      : 'text-[#AAB4C3]'
                  }`}
                >
                  Channel
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setLinkType('community')}
                  className={`px-3 py-1 rounded-lg text-xs font-medium transition ${
                    linkType === 'community'
                      ? 'bg-white/[0.15] text-white font-semibold'
                      : 'text-[#AAB4C3]'
                  }`}
                >
                  Community
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Inputs Card */}
        <div className="bg-[#0D1118] border border-white/[0.08] rounded-3xl p-4 flex flex-col gap-3.5">
          {/* Link URL */}
          <div>
            <label className="text-xs font-semibold text-[#AAB4C3] block mb-1">
              Link URL <span className="text-rose-400">*</span>
            </label>
            <div className="relative">
              <LinkIcon className="w-4 h-4 absolute left-3.5 top-3.5 text-[#AAB4C3]" />
              <input
                type="url"
                required
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder={
                  platform === 'whatsapp'
                    ? 'https://chat.whatsapp.com/...'
                    : 'https://t.me/...'
                }
                className="w-full bg-[#121824] border border-white/[0.08] focus:border-[#00E676] rounded-2xl pl-10 pr-4 py-3 text-xs text-white placeholder-[#AAB4C3]/40 focus:outline-none transition"
              />
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="text-xs font-semibold text-[#AAB4C3] block mb-1">
              Title <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Descriptive title..."
              maxLength={80}
              className="w-full bg-[#121824] border border-white/[0.08] focus:border-[#00E676] rounded-2xl px-4 py-3 text-xs text-white placeholder-[#AAB4C3]/40 focus:outline-none transition"
            />
          </div>

          {/* Category */}
          <div>
            <label className="text-xs font-semibold text-[#AAB4C3] block mb-1">
              Category <span className="text-rose-400">*</span>
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full bg-[#121824] border border-white/[0.08] focus:border-[#00E676] rounded-2xl px-4 py-3 text-xs text-white focus:outline-none transition appearance-none"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat} className="bg-[#121824] text-white">
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Optional Description */}
          <div>
            <label className="text-xs font-semibold text-[#AAB4C3] block mb-1">
              Description (Optional)
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add key highlights or purpose of this community..."
              rows={3}
              maxLength={240}
              className="w-full bg-[#121824] border border-white/[0.08] focus:border-[#00E676] rounded-2xl p-3.5 text-xs text-white placeholder-[#AAB4C3]/40 focus:outline-none transition resize-none"
            />
          </div>
        </div>

        {/* Error message */}
        {errorMessage && (
          <div className="bg-rose-500/15 border border-rose-500/30 rounded-2xl p-3 flex items-center gap-2 text-rose-300 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Success message */}
        {successNotice && (
          <div className="bg-[#00E676]/15 border border-[#00E676]/30 rounded-2xl p-3 flex items-center gap-2 text-[#00E676] text-xs font-semibold">
            <CheckCircle className="w-4 h-4 shrink-0 text-[#00E676]" />
            <span>{successNotice}</span>
          </div>
        )}

        {/* Buttons */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 py-3.5 rounded-2xl bg-white/[0.04] hover:bg-white/[0.08] text-[#AAB4C3] hover:text-white border border-white/[0.08] text-xs font-bold tap-bounce transition"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="flex-1 py-3.5 rounded-2xl bg-gradient-to-r from-[#00E676] to-[#00B0FF] text-[#05070C] text-xs font-extrabold tap-bounce transition shadow-lg shadow-[#00E676]/20 disabled:opacity-50"
          >
            {submitting ? 'Publishing...' : 'Publish'}
          </button>
        </div>
      </form>
    </div>
  );
};
