import React, { useState } from 'react';
import {
  ExternalLink,
  Share2,
  MoreVertical,
  Flag,
  Trash2,
  Info,
  Users,
  Send,
  Eye
} from 'lucide-react';
import { LinkItem } from '../types';

interface LinkCardProps {
  link: LinkItem;
  currentUid: string;
  isAdmin: boolean;
  onOpen: (link: LinkItem) => void;
  onShare: (link: LinkItem) => void;
  onDetails: (link: LinkItem) => void;
  onReport: (link: LinkItem) => void;
  onDelete: (link: LinkItem) => void;
}

export const LinkCard: React.FC<LinkCardProps> = ({
  link,
  currentUid,
  isAdmin,
  onOpen,
  onShare,
  onDetails,
  onReport,
  onDelete
}) => {
  const [showMenu, setShowMenu] = useState(false);
  const isOwner = link.publisherUid === currentUid || isAdmin;
  const isWhatsApp = link.platform === 'whatsapp';

  return (
    <div className="relative bg-[#0D1118] border border-white/[0.08] hover:border-white/[0.14] rounded-2xl p-4 transition-all duration-200 shadow-md">
      {/* Top row: Platform Tag, Category, More Options */}
      <div className="flex items-center justify-between gap-2 mb-2.5">
        <div className="flex items-center gap-2 flex-wrap">
          {/* Platform Badge */}
          <span
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold tracking-wide ${
              isWhatsApp
                ? 'bg-[#00E676]/15 text-[#00E676] border border-[#00E676]/30'
                : 'bg-[#2196F3]/15 text-[#2196F3] border border-[#2196F3]/30'
            }`}
          >
            {isWhatsApp ? (
              <Users className="w-3 h-3" />
            ) : (
              <Send className="w-3 h-3" />
            )}
            <span>{isWhatsApp ? 'WhatsApp' : 'Telegram'}</span>
            <span className="text-[10px] opacity-75 capitalize">
              • {link.linkType || 'group'}
            </span>
          </span>

          {/* Category Tag */}
          <span className="text-[11px] text-[#AAB4C3] bg-white/[0.04] px-2 py-0.5 rounded-md border border-white/[0.06]">
            {link.category}
          </span>
        </div>

        {/* Overflow Menu */}
        <div className="relative">
          <button
            onClick={() => setShowMenu(!showMenu)}
            aria-label="Link Options"
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#AAB4C3] hover:text-white hover:bg-white/[0.06] transition"
          >
            <MoreVertical className="w-4 h-4" />
          </button>

          {showMenu && (
            <>
              <div
                className="fixed inset-0 z-20"
                onClick={() => setShowMenu(false)}
              />
              <div className="absolute right-0 top-9 z-30 w-36 bg-[#121824] border border-white/[0.12] rounded-xl shadow-2xl py-1 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-100">
                <button
                  onClick={() => {
                    setShowMenu(false);
                    onDetails(link);
                  }}
                  className="w-full px-3 py-2 text-left text-xs text-white hover:bg-white/[0.08] flex items-center gap-2"
                >
                  <Info className="w-3.5 h-3.5 text-[#2196F3]" />
                  <span>Details</span>
                </button>
                <button
                  onClick={() => {
                    setShowMenu(false);
                    onReport(link);
                  }}
                  className="w-full px-3 py-2 text-left text-xs text-[#AAB4C3] hover:text-amber-400 hover:bg-white/[0.08] flex items-center gap-2"
                >
                  <Flag className="w-3.5 h-3.5" />
                  <span>Report</span>
                </button>
                {isOwner && (
                  <button
                    onClick={() => {
                      setShowMenu(false);
                      onDelete(link);
                    }}
                    className="w-full px-3 py-2 text-left text-xs text-rose-400 hover:bg-rose-500/10 flex items-center gap-2 border-t border-white/[0.06]"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                )}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Title */}
      <h3
        onClick={() => onDetails(link)}
        className="text-white font-semibold text-base leading-snug line-clamp-2 cursor-pointer hover:text-[#00E676] transition mb-3"
      >
        {link.title}
      </h3>

      {/* Stats and Action Buttons */}
      <div className="flex items-center justify-between pt-2 border-t border-white/[0.06]">
        {/* Statistics: Shares & Clicks */}
        <div className="flex items-center gap-3 text-xs text-[#AAB4C3]">
          <span className="flex items-center gap-1 font-medium" title="Share Count">
            <Share2 className="w-3.5 h-3.5 text-[#00E676]" />
            <span className="text-white font-semibold">{link.shareCount || 0}</span>
          </span>
          <span className="flex items-center gap-1 font-medium" title="Click Count">
            <Eye className="w-3.5 h-3.5 text-[#2196F3]" />
            <span className="text-white font-semibold">{link.clickCount || 0}</span>
          </span>
        </div>

        {/* Actions: Open & Share */}
        <div className="flex items-center gap-2">
          {/* Share Button */}
          <button
            onClick={() => onShare(link)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/[0.08] text-white text-xs font-semibold tap-bounce transition"
          >
            <Share2 className="w-3.5 h-3.5 text-[#00E676]" />
            <span>Share</span>
          </button>

          {/* Open Button */}
          <button
            onClick={() => onOpen(link)}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold tap-bounce transition shadow-sm ${
              isWhatsApp
                ? 'bg-[#00E676] text-[#05070C] hover:bg-[#00c864] shadow-[#00E676]/20'
                : 'bg-[#2196F3] text-white hover:bg-[#1e88e5] shadow-[#2196F3]/20'
            }`}
          >
            <span>Open</span>
            <ExternalLink className="w-3.5 h-3.5 stroke-[2.5]" />
          </button>
        </div>
      </div>
    </div>
  );
};
