import React, { useState } from 'react';
import { Search, Sparkles, X, Users, Send } from 'lucide-react';
import { LinkItem, PlatformType, LinkKind } from '../types';
import { LinkCard } from './LinkCard';
import { CATEGORIES } from '../services/linkService';

interface ExploreTabProps {
  links: LinkItem[];
  currentUid: string;
  isAdmin: boolean;
  onOpen: (link: LinkItem) => void;
  onShare: (link: LinkItem) => void;
  onDetails: (link: LinkItem) => void;
  onReport: (link: LinkItem) => void;
  onDelete: (link: LinkItem) => void;
}

export const ExploreTab: React.FC<ExploreTabProps> = ({
  links,
  currentUid,
  isAdmin,
  onOpen,
  onShare,
  onDetails,
  onReport,
  onDelete
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [platform, setPlatform] = useState<'all' | PlatformType>('all');
  const [kindFilter, setKindFilter] = useState<'all' | LinkKind>('all');
  const [category, setCategory] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'trending' | 'recent'>('trending');

  const filtered = links.filter((item) => {
    if (item.status !== 'active' && !isAdmin) return false;
    if (platform !== 'all' && item.platform !== platform) return false;
    if (kindFilter !== 'all' && item.linkType !== kindFilter) return false;
    if (category !== 'All' && item.category !== category) return false;

    if (searchQuery.trim().length > 0) {
      const q = searchQuery.toLowerCase().trim();
      const matchTitle = item.title.toLowerCase().includes(q);
      const matchDesc = item.description?.toLowerCase().includes(q);
      const matchCat = item.category.toLowerCase().includes(q);
      if (!matchTitle && !matchDesc && !matchCat) return false;
    }

    return true;
  });

  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === 'trending') {
      return (b.shareCount + b.clickCount) - (a.shareCount + a.clickCount);
    }
    return b.createdAt - a.createdAt;
  });

  return (
    <div className="flex flex-col gap-4 pb-24">
      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-[#AAB4C3]" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search by title, category, or keyword..."
          className="w-full bg-[#0D1118] border border-white/[0.08] focus:border-[#2196F3] rounded-2xl pl-10 pr-10 py-3 text-sm text-white placeholder-[#AAB4C3]/40 focus:outline-none transition shadow-inner"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="w-7 h-7 absolute right-2.5 top-2.5 rounded-full flex items-center justify-center text-[#AAB4C3] hover:text-white"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Filter Row: Platform & Types */}
      <div className="flex flex-col gap-2 bg-[#0D1118] border border-white/[0.08] p-3 rounded-2xl">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-[#AAB4C3]">Platform</span>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setPlatform('all')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
                platform === 'all'
                  ? 'bg-white text-black'
                  : 'text-[#AAB4C3] hover:text-white'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setPlatform('whatsapp')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
                platform === 'whatsapp'
                  ? 'bg-[#00E676] text-black font-bold'
                  : 'text-[#AAB4C3] hover:text-white'
              }`}
            >
              WhatsApp
            </button>
            <button
              onClick={() => setPlatform('telegram')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
                platform === 'telegram'
                  ? 'bg-[#2196F3] text-white font-bold'
                  : 'text-[#AAB4C3] hover:text-white'
              }`}
            >
              Telegram
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-white/[0.04]">
          <span className="text-xs font-semibold text-[#AAB4C3]">Format</span>
          <div className="flex items-center gap-1">
            {(['all', 'group', 'channel', 'community'] as const).map((k) => (
              <button
                key={k}
                onClick={() => setKindFilter(k)}
                className={`px-2 py-0.5 rounded-md text-[11px] capitalize transition ${
                  kindFilter === k
                    ? 'bg-white/[0.15] text-white font-semibold'
                    : 'text-[#AAB4C3] hover:text-white'
                }`}
              >
                {k}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Categories chips horizontal */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1 -mx-4 px-4">
        <button
          onClick={() => setCategory('All')}
          className={`px-3 py-1 rounded-full text-xs font-semibold shrink-0 transition ${
            category === 'All'
              ? 'bg-white text-black'
              : 'bg-white/[0.04] text-[#AAB4C3] border border-white/[0.08]'
          }`}
        >
          All
        </button>
        {CATEGORIES.map((c) => (
          <button
            key={c}
            onClick={() => setCategory(c)}
            className={`px-3 py-1 rounded-full text-xs font-semibold shrink-0 transition ${
              category === c
                ? 'bg-white text-black'
                : 'bg-white/[0.04] text-[#AAB4C3] border border-white/[0.08]'
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {/* Sort selection & Results count */}
      <div className="flex items-center justify-between px-1 text-xs text-[#AAB4C3]">
        <span>Found {sorted.length} links</span>
        <div className="flex items-center gap-1 bg-[#0D1118] p-1 rounded-xl border border-white/[0.06]">
          <button
            onClick={() => setSortBy('trending')}
            className={`px-2 py-0.5 rounded-lg font-medium transition ${
              sortBy === 'trending' ? 'bg-white/[0.12] text-white' : 'text-[#AAB4C3]'
            }`}
          >
            Trending
          </button>
          <button
            onClick={() => setSortBy('recent')}
            className={`px-2 py-0.5 rounded-lg font-medium transition ${
              sortBy === 'recent' ? 'bg-white/[0.12] text-white' : 'text-[#AAB4C3]'
            }`}
          >
            Recent
          </button>
        </div>
      </div>

      {/* Results List */}
      <div className="flex flex-col gap-3">
        {sorted.length === 0 ? (
          <div className="bg-[#0D1118] border border-white/[0.08] rounded-3xl p-8 text-center flex flex-col items-center justify-center">
            <div className="w-12 h-12 rounded-2xl bg-white/[0.04] flex items-center justify-center text-[#AAB4C3] mb-3">
              <Sparkles className="w-6 h-6" />
            </div>
            <p className="text-white font-semibold text-sm mb-1">No matching links</p>
            <p className="text-xs text-[#AAB4C3]">Try adjusting filters or search terms.</p>
          </div>
        ) : (
          sorted.map((item) => (
            <LinkCard
              key={item.id}
              link={item}
              currentUid={currentUid}
              isAdmin={isAdmin}
              onOpen={onOpen}
              onShare={onShare}
              onDetails={onDetails}
              onReport={onReport}
              onDelete={onDelete}
            />
          ))
        )}
      </div>
    </div>
  );
};
