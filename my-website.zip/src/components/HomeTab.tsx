import React, { useState } from 'react';
import { Sparkles, Users, Send } from 'lucide-react';
import { LinkItem, PlatformType } from '../types';
import { LinkCard } from './LinkCard';
import { YouTubeBanner } from './YouTubeBanner';
import { AdBanner } from './AdBanner';
import { CATEGORIES } from '../services/linkService';

interface HomeTabProps {
  links: LinkItem[];
  currentUid: string;
  isAdmin: boolean;
  adsEnabled: boolean;
  onOpen: (link: LinkItem) => void;
  onShare: (link: LinkItem) => void;
  onDetails: (link: LinkItem) => void;
  onReport: (link: LinkItem) => void;
  onDelete: (link: LinkItem) => void;
  onNavigatePublish: () => void;
}

export const HomeTab: React.FC<HomeTabProps> = ({
  links,
  currentUid,
  isAdmin,
  adsEnabled,
  onOpen,
  onShare,
  onDetails,
  onReport,
  onDelete,
  onNavigatePublish
}) => {
  const [platformFilter, setPlatformFilter] = useState<'all' | PlatformType>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const filteredLinks = links.filter((link) => {
    if (link.status !== 'active' && !isAdmin) return false;
    if (platformFilter !== 'all' && link.platform !== platformFilter) return false;
    if (selectedCategory !== 'All' && link.category !== selectedCategory) return false;
    return true;
  });

  return (
    <div className="flex flex-col gap-4 pb-24">
      {/* Category Pills Slider */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1 -mx-4 px-4">
        <button
          onClick={() => setSelectedCategory('All')}
          className={`px-3.5 py-1.5 rounded-full text-xs font-semibold shrink-0 transition ${
            selectedCategory === 'All'
              ? 'bg-white text-[#05070C] shadow-sm'
              : 'bg-white/[0.04] text-[#AAB4C3] border border-white/[0.08] hover:text-white'
          }`}
        >
          All Categories
        </button>
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold shrink-0 transition ${
              selectedCategory === cat
                ? 'bg-white text-[#05070C] shadow-sm'
                : 'bg-white/[0.04] text-[#AAB4C3] border border-white/[0.08] hover:text-white'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Platform Filter Buttons */}
      <div className="grid grid-cols-3 gap-2 bg-[#0D1118] border border-white/[0.08] p-1.5 rounded-2xl">
        <button
          onClick={() => setPlatformFilter('all')}
          className={`py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
            platformFilter === 'all'
              ? 'bg-white/[0.1] text-white'
              : 'text-[#AAB4C3] hover:text-white'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>All</span>
        </button>

        <button
          onClick={() => setPlatformFilter('whatsapp')}
          className={`py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
            platformFilter === 'whatsapp'
              ? 'bg-[#00E676]/20 border border-[#00E676]/30 text-[#00E676]'
              : 'text-[#AAB4C3] hover:text-white'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>WhatsApp</span>
        </button>

        <button
          onClick={() => setPlatformFilter('telegram')}
          className={`py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
            platformFilter === 'telegram'
              ? 'bg-[#2196F3]/20 border border-[#2196F3]/30 text-[#2196F3]'
              : 'text-[#AAB4C3] hover:text-white'
          }`}
        >
          <Send className="w-3.5 h-3.5" />
          <span>Telegram</span>
        </button>
      </div>

      {/* Official YouTube Channel Section (Requirement 22) */}
      <YouTubeBanner />

      {/* Primary Ad placement between hero and feed (Requirement 21) */}
      <AdBanner adsEnabled={adsEnabled} />

      {/* Feed links */}
      <div className="flex flex-col gap-3">
        {filteredLinks.length === 0 ? (
          <div className="bg-[#0D1118] border border-white/[0.08] rounded-3xl p-8 text-center flex flex-col items-center justify-center">
            <div className="w-12 h-12 rounded-2xl bg-white/[0.04] flex items-center justify-center text-[#AAB4C3] mb-3">
              <Sparkles className="w-6 h-6" />
            </div>
            <p className="text-white font-semibold text-sm mb-1">
              No links found
            </p>
            <p className="text-xs text-[#AAB4C3] max-w-xs mb-4">
              Be the first to share a verified link in this category.
            </p>
            <button
              onClick={onNavigatePublish}
              className="px-4 py-2 rounded-xl bg-[#00E676] text-[#05070C] text-xs font-bold tap-bounce transition"
            >
              Publish Link
            </button>
          </div>
        ) : (
          filteredLinks.map((link, idx) => (
            <React.Fragment key={link.id}>
              <LinkCard
                link={link}
                currentUid={currentUid}
                isAdmin={isAdmin}
                onOpen={onOpen}
                onShare={onShare}
                onDetails={onDetails}
                onReport={onReport}
                onDelete={onDelete}
              />
              {/* Secondary Ad placement between content cards */}
              {idx === 2 && <AdBanner adsEnabled={adsEnabled} />}
            </React.Fragment>
          ))
        )}
      </div>
    </div>
  );
};
