import React, { useState } from 'react';
import {
  User,
  Shield,
  Trash2,
  ExternalLink,
  Download,
  Share2,
  Eye,
  CheckCircle,
  HelpCircle,
  Smartphone
} from 'lucide-react';
import { LinkItem } from '../types';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface ProfileTabProps {
  currentUid: string;
  userLinks: LinkItem[];
  isAdmin: boolean;
  onOpenAdmin: () => void;
  onOpenLink: (link: LinkItem) => void;
  onDeleteLink: (link: LinkItem) => void;
  onNavigatePublish: () => void;
}

export const ProfileTab: React.FC<ProfileTabProps> = ({
  userLinks,
  isAdmin,
  onOpenAdmin,
  onOpenLink,
  onDeleteLink,
  onNavigatePublish
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSPrompt, setShowIOSPrompt] = useState(false);

  const totalMyShares = userLinks.reduce((sum, l) => sum + (l.shareCount || 0), 0);
  const totalMyClicks = userLinks.reduce((sum, l) => sum + (l.clickCount || 0), 0);

  return (
    <div className="flex flex-col gap-4 pb-24">
      {/* Account Profile Card */}
      <div className="bg-[#0D1118] border border-white/[0.08] rounded-3xl p-5 shadow-lg flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#00E676] to-[#2196F3] p-[2px] flex items-center justify-center shadow-lg shadow-[#00E676]/10">
            <div className="w-full h-full bg-[#0D1118] rounded-[14px] flex items-center justify-center">
              <User className="w-6 h-6 text-white" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-white font-bold text-base leading-tight">
                VIP Community Member
              </h2>
              {isAdmin && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#2196F3]/20 text-[#2196F3] border border-[#2196F3]/40">
                  Admin
                </span>
              )}
            </div>
            <p className="text-xs text-[#00E676] font-medium mt-0.5 flex items-center gap-1">
              <CheckCircle className="w-3.5 h-3.5" />
              <span>Verified Session</span>
            </p>
          </div>
        </div>

        <button
          onClick={onOpenAdmin}
          className="p-2.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] text-[#AAB4C3] hover:text-white tap-bounce transition"
          aria-label="Admin Portal"
        >
          <Shield className="w-5 h-5" />
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-3 gap-2.5">
        <div className="bg-[#0D1118] border border-white/[0.08] rounded-2xl p-3.5 text-center">
          <span className="text-[10px] text-[#AAB4C3] block uppercase tracking-wider">
            My Links
          </span>
          <span className="text-xl font-bold text-white mt-1 block">
            {userLinks.length}
          </span>
        </div>

        <div className="bg-[#0D1118] border border-white/[0.08] rounded-2xl p-3.5 text-center">
          <span className="text-[10px] text-[#AAB4C3] block uppercase tracking-wider">
            Total Shares
          </span>
          <span className="text-xl font-bold text-[#00E676] mt-1 block">
            {totalMyShares}
          </span>
        </div>

        <div className="bg-[#0D1118] border border-white/[0.08] rounded-2xl p-3.5 text-center">
          <span className="text-[10px] text-[#AAB4C3] block uppercase tracking-wider">
            Total Clicks
          </span>
          <span className="text-xl font-bold text-[#2196F3] mt-1 block">
            {totalMyClicks}
          </span>
        </div>
      </div>

      {/* PWA App Install Tile */}
      {!isInstalled && (
        <div className="bg-gradient-to-r from-[#121824] to-[#0D1118] border border-[#00E676]/30 rounded-3xl p-4 flex items-center justify-between gap-3 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#00E676]/20 text-[#00E676] flex items-center justify-center shrink-0">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-white font-bold text-xs">
                Install VIP Share
              </h3>
              <p className="text-[11px] text-[#AAB4C3]">
                Enjoy native Samsung One UI experience
              </p>
            </div>
          </div>

          {isInstallable ? (
            <button
              onClick={install}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#00E676] text-[#05070C] text-xs font-bold tap-bounce transition shadow-sm shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Install</span>
            </button>
          ) : isIOS ? (
            <button
              onClick={() => setShowIOSPrompt(true)}
              className="px-3 py-2 rounded-xl bg-white/[0.08] text-white text-xs font-semibold tap-bounce shrink-0"
            >
              iOS Guide
            </button>
          ) : (
            <span className="text-[11px] text-[#AAB4C3] bg-white/[0.04] px-2.5 py-1 rounded-lg">
              Installed
            </span>
          )}
        </div>
      )}

      {/* iOS Install Prompt Modal */}
      {showIOSPrompt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
          <div className="w-full max-w-sm bg-[#0D1118] border border-white/[0.12] rounded-3xl p-5 shadow-2xl flex flex-col gap-3">
            <h3 className="text-white font-bold text-sm">Install on Safari</h3>
            <p className="text-xs text-[#AAB4C3] leading-relaxed">
              1. Tap the <strong>Share</strong> button in Safari toolbar.<br />
              2. Scroll down and tap <strong>Add to Home Screen</strong>.
            </p>
            <button
              onClick={() => setShowIOSPrompt(false)}
              className="mt-2 w-full py-2.5 rounded-xl bg-[#2196F3] text-white text-xs font-bold"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* My Links Management Section */}
      <div className="flex flex-col gap-2.5">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-semibold text-[#AAB4C3]">
            My Published Links
          </span>
          <button
            onClick={onNavigatePublish}
            className="text-xs font-semibold text-[#00E676] hover:underline"
          >
            + New Link
          </button>
        </div>

        {userLinks.length === 0 ? (
          <div className="bg-[#0D1118] border border-white/[0.08] rounded-3xl p-8 text-center flex flex-col items-center justify-center">
            <HelpCircle className="w-8 h-8 text-[#AAB4C3] mb-2 opacity-50" />
            <p className="text-white font-semibold text-xs mb-1">
              You haven't published any links yet
            </p>
            <p className="text-[11px] text-[#AAB4C3] max-w-xs mb-3">
              Share WhatsApp and Telegram community links to grow engagement.
            </p>
            <button
              onClick={onNavigatePublish}
              className="px-4 py-2 rounded-xl bg-[#00E676] text-[#05070C] text-xs font-bold tap-bounce transition"
            >
              Publish Now
            </button>
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {userLinks.map((link) => (
              <div
                key={link.id}
                className="bg-[#0D1118] border border-white/[0.08] rounded-2xl p-3.5 flex flex-col gap-2 shadow-sm"
              >
                <div className="flex items-center justify-between">
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase ${
                      link.platform === 'whatsapp'
                        ? 'bg-[#00E676]/15 text-[#00E676]'
                        : 'bg-[#2196F3]/15 text-[#2196F3]'
                    }`}
                  >
                    {link.platform} • {link.category}
                  </span>
                  <div className="flex items-center gap-2 text-xs text-[#AAB4C3]">
                    <span className="flex items-center gap-1">
                      <Share2 className="w-3 h-3 text-[#00E676]" />
                      <span>{link.shareCount}</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <Eye className="w-3 h-3 text-[#2196F3]" />
                      <span>{link.clickCount}</span>
                    </span>
                  </div>
                </div>

                <p className="text-white text-xs font-semibold truncate">
                  {link.title}
                </p>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-white/[0.04]">
                  <button
                    onClick={() => onOpenLink(link)}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-white text-xs font-medium tap-bounce transition"
                  >
                    <span>Open</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>

                  <button
                    onClick={() => onDeleteLink(link)}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 text-xs font-medium tap-bounce transition"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
