import React from 'react';
import { Youtube, ExternalLink } from 'lucide-react';

export const YouTubeBanner: React.FC = () => {
  return (
    <div className="bg-gradient-to-r from-[#180A0A] to-[#121824] border border-red-500/20 rounded-2xl p-4 flex items-center justify-between gap-3 shadow-md">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-red-600/20 border border-red-500/30 flex items-center justify-center text-red-500 shrink-0">
          <Youtube className="w-5 h-5" />
        </div>
        <div className="flex flex-col">
          <span className="text-white font-bold text-sm leading-tight">
            Official Channel
          </span>
          <span className="text-[11px] text-[#AAB4C3]">
            @mtbangla.01
          </span>
        </div>
      </div>

      <a
        href="https://youtube.com/@mtbangla.01?si=XNnOq8cG3dBub7NH"
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold tap-bounce transition shadow-sm shrink-0"
      >
        <span>Watch on YouTube</span>
        <ExternalLink className="w-3.5 h-3.5" />
      </a>
    </div>
  );
};
