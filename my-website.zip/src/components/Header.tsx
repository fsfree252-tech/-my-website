import React from 'react';
import { Search, ShieldAlert, Download, Youtube } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface HeaderProps {
  onOpenSearch: () => void;
  onOpenAdmin: () => void;
  isAdmin: boolean;
  isOnline: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSearch,
  onOpenAdmin,
  isAdmin,
  isOnline
}) => {
  const { isInstallable, install } = usePWAInstall();

  return (
    <header className="sticky top-0 z-40 w-full bg-[#05070C]/90 backdrop-blur-xl border-b border-white/[0.08] transition-colors">
      <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#00E676] to-[#2196F3] p-[2px] shadow-lg shadow-[#00E676]/10 flex items-center justify-center">
            <div className="w-full h-full bg-[#05070C] rounded-[10px] flex items-center justify-center">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00E676] to-[#2196F3] font-black text-base tracking-tighter">
                VIP
              </span>
            </div>
          </div>
          <div className="flex flex-col">
            <span className="text-white font-bold text-lg leading-tight tracking-wide">
              VIP Share
            </span>
            <div className="flex items-center gap-1.5">
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  isOnline ? 'bg-[#00E676]' : 'bg-amber-500 animate-pulse'
                }`}
              />
              <span className="text-[11px] text-[#AAB4C3] font-medium leading-none">
                {isOnline ? 'Active' : 'Offline'}
              </span>
            </div>
          </div>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-1.5">
          {/* Official YouTube Channel shortcut */}
          <a
            href="https://youtube.com/@mtbangla.01?si=XNnOq8cG3dBub7NH"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="YouTube Channel"
            className="w-9 h-9 rounded-full bg-white/[0.04] border border-white/[0.08] flex items-center justify-center text-[#AAB4C3] hover:text-[#FF0000] hover:bg-white/[0.08] tap-bounce transition"
          >
            <Youtube className="w-4 h-4" />
          </a>

          {/* PWA Install Button */}
          {isInstallable && (
            <button
              onClick={install}
              aria-label="Install App"
              className="flex items-center gap-1 px-2.5 h-9 rounded-full bg-[#00E676]/15 border border-[#00E676]/30 text-[#00E676] text-xs font-semibold tap-bounce transition"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Install</span>
            </button>
          )}

          {/* Search Toggle */}
          <button
            onClick={onOpenSearch}
            aria-label="Search Links"
            className="w-9 h-9 rounded-full bg-white/[0.04] border border-white/[0.08] flex items-center justify-center text-[#AAB4C3] hover:text-white hover:bg-white/[0.08] tap-bounce transition"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Admin Toggle */}
          <button
            onClick={onOpenAdmin}
            aria-label="Admin Portal"
            className={`w-9 h-9 rounded-full border flex items-center justify-center tap-bounce transition ${
              isAdmin
                ? 'bg-[#2196F3]/20 border-[#2196F3] text-[#2196F3]'
                : 'bg-white/[0.04] border-white/[0.08] text-[#AAB4C3] hover:text-white'
            }`}
          >
            <ShieldAlert className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
