import React from 'react';
import { WifiOff } from 'lucide-react';

interface OfflineIndicatorProps {
  isOnline: boolean;
}

export const OfflineIndicator: React.FC<OfflineIndicatorProps> = ({ isOnline }) => {
  if (isOnline) return null;

  return (
    <div className="fixed top-18 left-4 right-4 z-50 max-w-md mx-auto bg-amber-500 text-black font-semibold text-xs py-2 px-3.5 rounded-2xl shadow-xl flex items-center justify-between animate-in slide-in-from-top duration-200">
      <div className="flex items-center gap-2">
        <WifiOff className="w-4 h-4 shrink-0" />
        <span>Offline Mode</span>
      </div>
      <span className="text-[11px] opacity-80">Cached data active</span>
    </div>
  );
};
