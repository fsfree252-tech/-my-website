import React from 'react';
import {
  X,
  Share2,
  ExternalLink,
  Flag,
  Calendar,
  Eye,
  Users,
  Send,
  Tag
} from 'lucide-react';
import { LinkItem } from '../types';

interface LinkDetailsModalProps {
  link: LinkItem | null;
  onClose: () => void;
  onOpen: (link: LinkItem) => void;
  onShare: (link: LinkItem) => void;
  onReport: (link: LinkItem) => void;
}

export const LinkDetailsModal: React.FC<LinkDetailsModalProps> = ({
  link,
  onClose,
  onOpen,
  onShare,
  onReport
}) => {
  if (!link) return null;

  const isWhatsApp = link.platform === 'whatsapp';
  const formattedDate = new Date(link.createdAt).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-[#0D1118] border border-white/[0.12] rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl flex flex-col gap-4 max-h-[85vh] overflow-y-auto animate-in slide-in-from-bottom duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
          <span
            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold ${
              isWhatsApp
                ? 'bg-[#00E676]/15 text-[#00E676] border border-[#00E676]/30'
                : 'bg-[#2196F3]/15 text-[#2196F3] border border-[#2196F3]/30'
            }`}
          >
            {isWhatsApp ? (
              <Users className="w-3.5 h-3.5" />
            ) : (
              <Send className="w-3.5 h-3.5" />
            )}
            <span>{isWhatsApp ? 'WhatsApp' : 'Telegram'}</span>
            <span className="capitalize text-[10px] opacity-75">
              • {link.linkType || 'group'}
            </span>
          </span>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#AAB4C3] hover:text-white hover:bg-white/[0.08] transition"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Title */}
        <h2 className="text-white font-bold text-lg leading-snug">
          {link.title}
        </h2>

        {/* Description if available */}
        {link.description && (
          <div className="bg-[#121824] rounded-2xl p-3.5 border border-white/[0.06] text-xs text-[#AAB4C3] leading-relaxed">
            {link.description}
          </div>
        )}

        {/* Meta Stats Grid */}
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-2.5 flex flex-col items-center justify-center text-center">
            <Tag className="w-4 h-4 text-[#AAB4C3] mb-1" />
            <span className="text-[10px] text-[#AAB4C3]">Category</span>
            <span className="text-xs font-semibold text-white truncate max-w-full">
              {link.category}
            </span>
          </div>

          <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-2.5 flex flex-col items-center justify-center text-center">
            <Share2 className="w-4 h-4 text-[#00E676] mb-1" />
            <span className="text-[10px] text-[#AAB4C3]">Shares</span>
            <span className="text-xs font-semibold text-white">
              {link.shareCount || 0}
            </span>
          </div>

          <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-2.5 flex flex-col items-center justify-center text-center">
            <Eye className="w-4 h-4 text-[#2196F3] mb-1" />
            <span className="text-[10px] text-[#AAB4C3]">Clicks</span>
            <span className="text-xs font-semibold text-white">
              {link.clickCount || 0}
            </span>
          </div>
        </div>

        {/* Date Row */}
        <div className="flex items-center gap-2 text-xs text-[#AAB4C3] px-1">
          <Calendar className="w-3.5 h-3.5" />
          <span>Published on {formattedDate}</span>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2.5 pt-2 border-t border-white/[0.08]">
          <button
            onClick={() => {
              onClose();
              onReport(link);
            }}
            className="flex items-center justify-center gap-1.5 px-3 py-3 rounded-2xl bg-white/[0.04] hover:bg-white/[0.08] text-[#AAB4C3] hover:text-amber-400 border border-white/[0.08] text-xs font-semibold tap-bounce transition"
          >
            <Flag className="w-4 h-4" />
            <span>Report</span>
          </button>

          <button
            onClick={() => {
              onClose();
              onShare(link);
            }}
            className="flex-1 flex items-center justify-center gap-1.5 py-3 rounded-2xl bg-white/[0.06] hover:bg-white/[0.12] text-white border border-white/[0.08] text-xs font-semibold tap-bounce transition"
          >
            <Share2 className="w-4 h-4 text-[#00E676]" />
            <span>Share</span>
          </button>

          <button
            onClick={() => {
              onClose();
              onOpen(link);
            }}
            className={`flex-1 flex items-center justify-center gap-1.5 py-3 rounded-2xl text-xs font-bold tap-bounce transition shadow-md ${
              isWhatsApp
                ? 'bg-[#00E676] text-[#05070C] hover:bg-[#00c864]'
                : 'bg-[#2196F3] text-white hover:bg-[#1e88e5]'
            }`}
          >
            <span>Open</span>
            <ExternalLink className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>
      </div>
    </div>
  );
};
