import React, { useEffect, useRef } from 'react';

interface AdBannerProps {
  adsEnabled: boolean;
}

export const AdBanner: React.FC<AdBannerProps> = ({ adsEnabled }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const scriptLoadedRef = useRef<boolean>(false);

  useEffect(() => {
    if (!adsEnabled || !containerRef.current || scriptLoadedRef.current) return;

    try {
      const script = document.createElement('script');
      script.src = 'https://pl28977919.profitableratecpmnetwork.com/27/38/2b/27382bca34dab06e0aaf500abee92bba.js';
      script.async = true;
      script.type = 'text/javascript';

      containerRef.current.appendChild(script);
      scriptLoadedRef.current = true;
    } catch {
      // Ad blocker or script failure handled gracefully
    }
  }, [adsEnabled]);

  if (!adsEnabled) return null;

  return (
    <div className="w-full bg-[#0D1118] border border-white/[0.08] rounded-2xl p-3 my-2 text-center overflow-hidden">
      <div className="flex items-center justify-between mb-2">
        <span className="text-[10px] uppercase tracking-wider text-[#AAB4C3]/60 font-semibold">
          Sponsored
        </span>
      </div>

      <div
        ref={containerRef}
        id="ad-placement-feed"
        className="min-h-[60px] flex items-center justify-center text-xs text-[#AAB4C3]/50"
      >
        <span className="text-[11px] text-[#AAB4C3]/40">Partner Network</span>
      </div>
    </div>
  );
};
