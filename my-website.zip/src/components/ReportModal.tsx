import React, { useState } from 'react';
import { X, Flag, Check, AlertCircle } from 'lucide-react';
import { LinkItem, ReportReason } from '../types';
import { submitReport } from '../services/linkService';

interface ReportModalProps {
  link: LinkItem | null;
  currentUid: string;
  onClose: () => void;
}

const REASONS: ReportReason[] = [
  'Invalid Link',
  'Spam',
  'Scam',
  'Misleading',
  'Inappropriate',
  'Other'
];

export const ReportModal: React.FC<ReportModalProps> = ({
  link,
  currentUid,
  onClose
}) => {
  const [selectedReason, setSelectedReason] = useState<ReportReason>('Invalid Link');
  const [details, setDetails] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!link) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    setSubmitting(true);
    setError(null);

    try {
      const res = await submitReport({
        linkId: link.id,
        linkTitle: link.title,
        reportedBy: currentUid,
        reason: selectedReason,
        details: details.trim()
      });

      if (res.success) {
        setSubmitted(true);
        setTimeout(() => {
          onClose();
        }, 1500);
      } else {
        setError(res.error || 'Failed to submit report.');
      }
    } catch {
      setError('An error occurred. Try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-[#0D1118] border border-white/[0.12] rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl flex flex-col gap-4 animate-in slide-in-from-bottom duration-200"
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500/15 flex items-center justify-center text-amber-400">
              <Flag className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-white font-bold text-base leading-tight">
                Report Link
              </h2>
              <p className="text-[11px] text-[#AAB4C3]">
                Help keep the community safe
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#AAB4C3] hover:text-white hover:bg-white/[0.08] transition"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {submitted ? (
          <div className="py-6 flex flex-col items-center justify-center text-center gap-2">
            <div className="w-12 h-12 rounded-full bg-[#00E676]/20 text-[#00E676] flex items-center justify-center">
              <Check className="w-6 h-6" />
            </div>
            <p className="text-white font-semibold text-sm">Report submitted</p>
            <p className="text-xs text-[#AAB4C3]">
              Thank you for keeping VIP Share safe.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col gap-3.5">
            <div className="bg-[#121824] rounded-2xl p-3 border border-white/[0.06]">
              <span className="text-[10px] text-[#AAB4C3] uppercase tracking-wider block">
                Target Link
              </span>
              <p className="text-xs font-semibold text-white truncate">
                {link.title}
              </p>
            </div>

            <div>
              <label className="text-xs text-[#AAB4C3] font-medium mb-1.5 block">
                Select Reason
              </label>
              <div className="grid grid-cols-2 gap-2">
                {REASONS.map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setSelectedReason(r)}
                    className={`px-3 py-2 rounded-xl text-xs font-medium text-left border transition ${
                      selectedReason === r
                        ? 'bg-[#2196F3]/15 border-[#2196F3] text-white'
                        : 'bg-white/[0.03] border-white/[0.08] text-[#AAB4C3] hover:text-white'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs text-[#AAB4C3] font-medium mb-1.5 block">
                Additional Details (Optional)
              </label>
              <textarea
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder="Describe the issue..."
                rows={2}
                className="w-full bg-[#121824] border border-white/[0.08] rounded-xl p-3 text-xs text-white placeholder-[#AAB4C3]/40 focus:outline-none focus:border-[#2196F3] transition"
              />
            </div>

            {error && (
              <div className="flex items-center gap-1.5 text-xs text-rose-400">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{error}</span>
              </div>
            )}

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 rounded-xl bg-white/[0.04] text-[#AAB4C3] hover:text-white border border-white/[0.08] text-xs font-semibold tap-bounce transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-black text-xs font-bold tap-bounce transition disabled:opacity-50"
              >
                {submitting ? 'Submitting...' : 'Submit Report'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
