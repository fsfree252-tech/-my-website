import React, { useState } from 'react';
import {
  X,
  Share2,
  Copy,
  Check,
  Send,
  Users,
  Smartphone,
  AlertCircle
} from 'lucide-react';
import { LinkItem } from '../types';
import { recordShare } from '../services/linkService';

interface ShareModalProps {
  link: LinkItem | null;
  currentUid: string;
  onClose: () => void;
  onShareRecorded: (linkId: string) => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  link,
  currentUid,
  onClose,
  onShareRecorded
}) => {
  const [copied, setCopied] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  if (!link) return null;

  const shareText = `VIP Share\n\n${link.title}\n\n${link.url}`;

  // Execute share method after atomic backend check
  const handleShareMethod = async (method: 'whatsapp' | 'telegram' | 'native' | 'copy') => {
    if (isProcessing) return;
    setIsProcessing(true);
    setErrorMessage(null);
    setSuccessNotice(null);

    try {
      // 1. Enforce atomic One-Share-Per-User rule in Firebase
      const res = await recordShare(link.id, currentUid, method);

      if (!res.success) {
        setErrorMessage(res.error || 'Link already shared by your account.');
        setIsProcessing(false);
        return;
      }

      // Notify parent to increment counter locally immediately
      onShareRecorded(link.id);

      // 2. Perform requested sharing action
      if (method === 'whatsapp') {
        const encodedText = encodeURIComponent(shareText);
        window.open(`https://api.whatsapp.com/send?text=${encodedText}`, '_blank');
      } else if (method === 'telegram') {
        const encodedUrl = encodeURIComponent(link.url);
        const encodedText = encodeURIComponent(`VIP Share\n\n${link.title}`);
        window.open(`https://t.me/share/url?url=${encodedUrl}&text=${encodedText}`, '_blank');
      } else if (method === 'native') {
        if (navigator.share) {
          try {
            await navigator.share({
              title: 'VIP Share',
              text: `VIP Share\n\n${link.title}`,
              url: link.url
            });
          } catch {
            // User cancelled share dialog
          }
        } else {
          // Fallback to clipboard
          await navigator.clipboard.writeText(shareText);
          setCopied(true);
        }
      } else if (method === 'copy') {
        await navigator.clipboard.writeText(shareText);
        setCopied(true);
        setTimeout(() => setCopied(false), 2500);
      }

      setSuccessNotice('Share recorded successfully.');
      setTimeout(() => {
        onClose();
      }, 1200);
    } catch {
      setErrorMessage('Could not record share. Try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const hasNativeShare = typeof navigator !== 'undefined' && !!navigator.share;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-[#0D1118] border border-white/[0.12] rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl flex flex-col gap-4 animate-in slide-in-from-bottom duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#00E676]/15 flex items-center justify-center text-[#00E676]">
              <Share2 className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-white font-bold text-base leading-tight">
                Share Link
              </h2>
              <p className="text-[11px] text-[#AAB4C3]">
                One share per account limit enforced
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#AAB4C3] hover:text-white hover:bg-white/[0.08] transition"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Link summary */}
        <div className="bg-[#121824] rounded-2xl p-3 border border-white/[0.06]">
          <p className="text-white text-xs font-semibold line-clamp-1">
            {link.title}
          </p>
          <p className="text-[11px] text-[#AAB4C3] truncate mt-0.5">
            {link.url}
          </p>
        </div>

        {/* Error / Duplicate Share Alert */}
        {errorMessage && (
          <div className="bg-rose-500/15 border border-rose-500/30 rounded-xl p-3 flex items-center gap-2 text-rose-300 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Success Notice */}
        {successNotice && (
          <div className="bg-[#00E676]/15 border border-[#00E676]/30 rounded-xl p-3 flex items-center gap-2 text-[#00E676] text-xs font-medium">
            <Check className="w-4 h-4 shrink-0 text-[#00E676]" />
            <span>{successNotice}</span>
          </div>
        )}

        {/* Share Action Grid */}
        <div className="grid grid-cols-2 gap-2.5">
          {/* WhatsApp Share */}
          <button
            disabled={isProcessing}
            onClick={() => handleShareMethod('whatsapp')}
            className="flex items-center gap-2.5 p-3 rounded-2xl bg-[#00E676]/10 hover:bg-[#00E676]/20 border border-[#00E676]/30 text-white tap-bounce transition disabled:opacity-50"
          >
            <div className="w-9 h-9 rounded-xl bg-[#00E676] text-[#05070C] flex items-center justify-center shrink-0">
              <Users className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div className="text-left">
              <div className="text-xs font-bold text-white">WhatsApp</div>
              <div className="text-[10px] text-[#AAB4C3]">Direct Share</div>
            </div>
          </button>

          {/* Telegram Share */}
          <button
            disabled={isProcessing}
            onClick={() => handleShareMethod('telegram')}
            className="flex items-center gap-2.5 p-3 rounded-2xl bg-[#2196F3]/10 hover:bg-[#2196F3]/20 border border-[#2196F3]/30 text-white tap-bounce transition disabled:opacity-50"
          >
            <div className="w-9 h-9 rounded-xl bg-[#2196F3] text-white flex items-center justify-center shrink-0">
              <Send className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div className="text-left">
              <div className="text-xs font-bold text-white">Telegram</div>
              <div className="text-[10px] text-[#AAB4C3]">Direct Share</div>
            </div>
          </button>

          {/* Native Android Share */}
          {hasNativeShare && (
            <button
              disabled={isProcessing}
              onClick={() => handleShareMethod('native')}
              className="flex items-center gap-2.5 p-3 rounded-2xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] text-white tap-bounce transition disabled:opacity-50"
            >
              <div className="w-9 h-9 rounded-xl bg-white/[0.1] text-white flex items-center justify-center shrink-0">
                <Smartphone className="w-5 h-5" />
              </div>
              <div className="text-left">
                <div className="text-xs font-bold text-white">Android Share</div>
                <div className="text-[10px] text-[#AAB4C3]">Share Sheet</div>
              </div>
            </button>
          )}

          {/* Copy Link */}
          <button
            disabled={isProcessing}
            onClick={() => handleShareMethod('copy')}
            className={`flex items-center gap-2.5 p-3 rounded-2xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] text-white tap-bounce transition disabled:opacity-50 ${
              !hasNativeShare ? 'col-span-2' : ''
            }`}
          >
            <div className="w-9 h-9 rounded-xl bg-white/[0.1] text-white flex items-center justify-center shrink-0">
              {copied ? (
                <Check className="w-5 h-5 text-[#00E676]" />
              ) : (
                <Copy className="w-5 h-5" />
              )}
            </div>
            <div className="text-left">
              <div className="text-xs font-bold text-white">
                {copied ? 'Copied' : 'Copy Link'}
              </div>
              <div className="text-[10px] text-[#AAB4C3]">To Clipboard</div>
            </div>
          </button>
        </div>

        {/* Note */}
        <p className="text-[11px] text-[#AAB4C3] text-center mt-1">
          Shares are tracked anonymously per account to maintain community integrity.
        </p>
      </div>
    </div>
  );
};
