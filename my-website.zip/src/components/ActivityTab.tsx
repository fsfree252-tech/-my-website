import React from 'react';
import { Activity as ActivityIcon, Share2, PlusCircle, ExternalLink, Calendar } from 'lucide-react';
import { UserActivity, LinkItem } from '../types';

interface ActivityTabProps {
  activities: UserActivity[];
  userLinks: LinkItem[];
  onSelectLink: (linkId: string) => void;
  onNavigatePublish: () => void;
}

export const ActivityTab: React.FC<ActivityTabProps> = ({
  activities,
  userLinks,
  onSelectLink,
  onNavigatePublish
}) => {
  return (
    <div className="flex flex-col gap-4 pb-24">
      {/* Header */}
      <div className="bg-[#0D1118] border border-white/[0.08] rounded-3xl p-5 shadow-lg">
        <div className="flex items-center gap-2.5 mb-1">
          <div className="w-8 h-8 rounded-xl bg-[#2196F3]/15 flex items-center justify-center text-[#2196F3]">
            <ActivityIcon className="w-5 h-5 stroke-[2.5]" />
          </div>
          <h2 className="text-white font-bold text-lg leading-tight">
            Account Activity
          </h2>
        </div>
        <p className="text-xs text-[#AAB4C3]">
          Your published links and confirmed sharing history on this device.
        </p>
      </div>

      {/* Summary counters */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className="bg-[#0D1118] border border-white/[0.08] rounded-2xl p-4">
          <div className="flex items-center gap-2 text-xs text-[#AAB4C3] mb-1">
            <PlusCircle className="w-4 h-4 text-[#00E676]" />
            <span>Published</span>
          </div>
          <div className="text-2xl font-bold text-white">
            {userLinks.length}
          </div>
        </div>

        <div className="bg-[#0D1118] border border-white/[0.08] rounded-2xl p-4">
          <div className="flex items-center gap-2 text-xs text-[#AAB4C3] mb-1">
            <Share2 className="w-4 h-4 text-[#2196F3]" />
            <span>Shares Recorded</span>
          </div>
          <div className="text-2xl font-bold text-[#00E676]">
            {activities.filter((a) => a.type === 'share').length}
          </div>
        </div>
      </div>

      {/* Recent Activity Stream */}
      <div className="flex flex-col gap-2.5">
        <span className="text-xs font-semibold text-[#AAB4C3] px-1">
          Recent Actions
        </span>

        {activities.length === 0 && userLinks.length === 0 ? (
          <div className="bg-[#0D1118] border border-white/[0.08] rounded-3xl p-8 text-center flex flex-col items-center justify-center">
            <div className="w-12 h-12 rounded-2xl bg-white/[0.04] flex items-center justify-center text-[#AAB4C3] mb-3">
              <ActivityIcon className="w-6 h-6" />
            </div>
            <p className="text-white font-semibold text-sm mb-1">
              No recent activity
            </p>
            <p className="text-xs text-[#AAB4C3] max-w-xs mb-4">
              Share or publish links to build your community footprint.
            </p>
            <button
              onClick={onNavigatePublish}
              className="px-4 py-2 rounded-xl bg-[#00E676] text-[#05070C] text-xs font-bold tap-bounce transition"
            >
              Publish a Link
            </button>
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {/* Show user's published links first */}
            {userLinks.map((link) => (
              <div
                key={`pub_${link.id}`}
                onClick={() => onSelectLink(link.id)}
                className="bg-[#0D1118] border border-white/[0.08] hover:border-white/[0.14] rounded-2xl p-3.5 flex items-center justify-between gap-3 tap-bounce transition cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-[#00E676]/15 text-[#00E676] flex items-center justify-center shrink-0">
                    <PlusCircle className="w-5 h-5" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-white text-xs font-semibold line-clamp-1">
                      {link.title}
                    </span>
                    <span className="text-[11px] text-[#AAB4C3]">
                      Published • {link.shareCount} shares • {link.clickCount} clicks
                    </span>
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-[#AAB4C3] shrink-0" />
              </div>
            ))}

            {/* Show user's share actions */}
            {activities.map((act) => (
              <div
                key={act.id}
                onClick={() => onSelectLink(act.linkId)}
                className="bg-[#0D1118] border border-white/[0.08] rounded-2xl p-3.5 flex items-center justify-between gap-3 tap-bounce transition cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-[#2196F3]/15 text-[#2196F3] flex items-center justify-center shrink-0">
                    <Share2 className="w-5 h-5" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-white text-xs font-semibold line-clamp-1">
                      {act.linkTitle}
                    </span>
                    <span className="text-[11px] text-[#AAB4C3] flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      <span>
                        Shared via {act.platform}
                      </span>
                    </span>
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-[#AAB4C3] shrink-0" />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
