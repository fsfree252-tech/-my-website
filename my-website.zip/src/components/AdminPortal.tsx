import React, { useState, useEffect } from 'react';
import {
  X,
  Shield,
  ShieldCheck,
  Eye,
  Share2,
  Trash2,
  AlertTriangle,
  CheckCircle,
  ToggleLeft,
  ToggleRight,
  Search,
  Lock,
  RefreshCw,
  Sliders,
  ExternalLink
} from 'lucide-react';
import { LinkItem, ReportItem, AppSettings } from '../types';
import {
  fetchReports,
  updateReportStatus,
  updateLinkStatus,
  deleteLink,
  getAppSettings,
  updateAppSettings
} from '../services/linkService';

interface AdminPortalProps {
  isOpen: boolean;
  onClose: () => void;
  links: LinkItem[];
  currentUid: string;
  isAdmin: boolean;
  onAdminAuthSuccess: () => void;
  onRefreshData: () => void;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({
  isOpen,
  onClose,
  links,
  currentUid,
  isAdmin,
  onAdminAuthSuccess,
  onRefreshData
}) => {
  const [activeTab, setActiveTab] = useState<'stats' | 'links' | 'reports' | 'settings'>('stats');
  const [adminKey, setAdminKey] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);

  // Admin data states
  const [reports, setReports] = useState<ReportItem[]>([]);
  const [loadingReports, setLoadingReports] = useState(false);
  const [linkSearch, setLinkSearch] = useState('');
  const [settings, setSettings] = useState<AppSettings>({
    adsEnabled: true,
    publishingEnabled: true,
    maintenanceMode: false
  });
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && isAdmin) {
      loadAdminData();
    }
  }, [isOpen, isAdmin]);

  const loadAdminData = async () => {
    setLoadingReports(true);
    try {
      const rep = await fetchReports();
      setReports(rep);
      const setts = await getAppSettings();
      setSettings(setts);
    } catch {
      // Handled
    } finally {
      setLoadingReports(false);
    }
  };

  const showNotification = (msg: string) => {
    setActionNotice(msg);
    setTimeout(() => setActionNotice(null), 3000);
  };

  // Secure SHA-256 administrative key verification
  const handleVerifyAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adminKey.trim()) return;

    setIsVerifying(true);
    setAuthError(null);

    try {
      const encoder = new TextEncoder();
      const data = encoder.encode(adminKey.trim());
      const hashBuffer = await crypto.subtle.digest('SHA-256', data);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');

      // SHA-256 of primary admin keys (e.g. VIPShareAdmin2026! / secure key)
      const validHashes = [
        '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', // 'test' hash
        '43f3246ebcfd36a94fdbfa551c6e1cb2a013d5cfdf3a67d02ff56cf3a9489f66', // 'VIPShareAdmin2026!'
        '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918'  // 'admin'
      ];

      if (validHashes.includes(hashHex) || adminKey.trim() === 'VIPShareAdmin2026!') {
        onAdminAuthSuccess();
        setAdminKey('');
        showNotification('Administrator authenticated');
      } else {
        setAuthError('Invalid administrative key');
      }
    } catch {
      setAuthError('Authentication verification failed');
    } finally {
      setIsVerifying(false);
    }
  };

  // Admin Link Operations
  const handleToggleStatus = async (link: LinkItem) => {
    const newStatus = link.status === 'active' ? 'disabled' : 'active';
    await updateLinkStatus(link.id, newStatus);
    showNotification(`Link marked as ${newStatus}`);
    onRefreshData();
  };

  const handleDelete = async (link: LinkItem) => {
    if (confirm(`Delete "${link.title}" permanently?`)) {
      const res = await deleteLink(link.id, link.publisherUid, currentUid, true);
      if (res.success) {
        showNotification('Link removed permanently');
        onRefreshData();
      }
    }
  };

  // Report Operations
  const handleResolveReport = async (reportId: string, status: 'resolved' | 'dismissed') => {
    await updateReportStatus(reportId, status);
    setReports((prev) =>
      prev.map((r) => (r.id === reportId ? { ...r, status } : r))
    );
    showNotification(`Report marked as ${status}`);
  };

  // Settings Toggles
  const handleToggleSetting = async (key: keyof AppSettings) => {
    const updated = { ...settings, [key]: !settings[key] };
    setSettings(updated);
    await updateAppSettings({ [key]: updated[key] });
    showNotification('Settings updated');
  };

  if (!isOpen) return null;

  const totalShares = links.reduce((sum, l) => sum + (l.shareCount || 0), 0);
  const totalClicks = links.reduce((sum, l) => sum + (l.clickCount || 0), 0);
  const pendingReports = reports.filter((r) => r.status === 'pending');

  const filteredLinks = links.filter((l) =>
    l.title.toLowerCase().includes(linkSearch.toLowerCase()) ||
    l.category.toLowerCase().includes(linkSearch.toLowerCase()) ||
    l.platform.toLowerCase().includes(linkSearch.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-[#0D1118] border border-white/[0.12] rounded-3xl p-5 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-white/[0.08] pb-3 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-[#2196F3]/15 flex items-center justify-center text-[#2196F3]">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-white font-bold text-base leading-tight">
                Admin Console
              </h2>
              <p className="text-[11px] text-[#AAB4C3]">
                System controls & moderation
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#AAB4C3] hover:text-white hover:bg-white/[0.08] transition"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {actionNotice && (
          <div className="mt-3 bg-[#00E676]/15 border border-[#00E676]/30 text-[#00E676] text-xs p-2 rounded-xl flex items-center gap-2">
            <CheckCircle className="w-4 h-4 shrink-0" />
            <span>{actionNotice}</span>
          </div>
        )}

        {/* If NOT Authenticated, show login gate */}
        {!isAdmin ? (
          <div className="py-8 flex flex-col items-center justify-center">
            <div className="w-14 h-14 rounded-2xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-center text-white mb-4">
              <Lock className="w-7 h-7 text-[#2196F3]" />
            </div>
            <h3 className="text-white font-bold text-base mb-1">
              Administrator Authentication
            </h3>
            <p className="text-xs text-[#AAB4C3] text-center max-w-xs mb-6">
              Enter authorized administrative credentials to access controls.
            </p>

            <form onSubmit={handleVerifyAdmin} className="w-full max-w-sm flex flex-col gap-3">
              <input
                type="password"
                value={adminKey}
                onChange={(e) => setAdminKey(e.target.value)}
                placeholder="Enter security key..."
                className="w-full bg-[#121824] border border-white/[0.12] rounded-xl px-4 py-3 text-sm text-white placeholder-[#AAB4C3]/40 focus:outline-none focus:border-[#2196F3] transition"
              />

              {authError && (
                <div className="flex items-center gap-1.5 text-xs text-rose-400">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>{authError}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={isVerifying}
                className="w-full py-3 rounded-xl bg-[#2196F3] hover:bg-[#1e88e5] text-white text-xs font-bold tap-bounce transition shadow-lg shadow-[#2196F3]/20 disabled:opacity-50"
              >
                {isVerifying ? 'Authenticating...' : 'Authenticate'}
              </button>
            </form>
          </div>
        ) : (
          /* Authenticated Admin Dashboard */
          <div className="flex flex-col flex-1 min-h-0 pt-3">
            {/* Tabs */}
            <div className="flex items-center gap-1.5 p-1 bg-white/[0.04] rounded-2xl shrink-0 mb-3">
              <button
                onClick={() => setActiveTab('stats')}
                className={`flex-1 py-1.5 rounded-xl text-xs font-semibold transition ${
                  activeTab === 'stats'
                    ? 'bg-[#2196F3] text-white shadow-sm'
                    : 'text-[#AAB4C3] hover:text-white'
                }`}
              >
                Stats
              </button>
              <button
                onClick={() => setActiveTab('links')}
                className={`flex-1 py-1.5 rounded-xl text-xs font-semibold transition ${
                  activeTab === 'links'
                    ? 'bg-[#2196F3] text-white shadow-sm'
                    : 'text-[#AAB4C3] hover:text-white'
                }`}
              >
                Links ({links.length})
              </button>
              <button
                onClick={() => setActiveTab('reports')}
                className={`flex-1 py-1.5 rounded-xl text-xs font-semibold transition relative ${
                  activeTab === 'reports'
                    ? 'bg-[#2196F3] text-white shadow-sm'
                    : 'text-[#AAB4C3] hover:text-white'
                }`}
              >
                Reports
                {pendingReports.length > 0 && (
                  <span className="ml-1 px-1.5 py-0.2 bg-rose-500 text-white rounded-full text-[10px]">
                    {pendingReports.length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('settings')}
                className={`flex-1 py-1.5 rounded-xl text-xs font-semibold transition ${
                  activeTab === 'settings'
                    ? 'bg-[#2196F3] text-white shadow-sm'
                    : 'text-[#AAB4C3] hover:text-white'
                }`}
              >
                Controls
              </button>
            </div>

            {/* Scrollable Tab Content */}
            <div className="flex-1 overflow-y-auto pr-1">
              {/* STATS TAB */}
              {activeTab === 'stats' && (
                <div className="flex flex-col gap-3 py-1">
                  <div className="grid grid-cols-2 gap-2.5">
                    <div className="bg-[#121824] border border-white/[0.06] rounded-2xl p-4">
                      <span className="text-[11px] text-[#AAB4C3]">Total Links</span>
                      <div className="text-2xl font-bold text-white mt-1">
                        {links.length}
                      </div>
                    </div>
                    <div className="bg-[#121824] border border-white/[0.06] rounded-2xl p-4">
                      <span className="text-[11px] text-[#AAB4C3]">Total Shares</span>
                      <div className="text-2xl font-bold text-[#00E676] mt-1">
                        {totalShares}
                      </div>
                    </div>
                    <div className="bg-[#121824] border border-white/[0.06] rounded-2xl p-4">
                      <span className="text-[11px] text-[#AAB4C3]">Total Clicks</span>
                      <div className="text-2xl font-bold text-[#2196F3] mt-1">
                        {totalClicks}
                      </div>
                    </div>
                    <div className="bg-[#121824] border border-white/[0.06] rounded-2xl p-4">
                      <span className="text-[11px] text-[#AAB4C3]">Pending Reports</span>
                      <div className="text-2xl font-bold text-amber-400 mt-1">
                        {pendingReports.length}
                      </div>
                    </div>
                  </div>

                  <div className="bg-[#121824] border border-white/[0.06] rounded-2xl p-4 mt-1">
                    <span className="text-xs font-semibold text-white block mb-2">
                      System Status
                    </span>
                    <div className="flex flex-col gap-2 text-xs">
                      <div className="flex justify-between items-center text-[#AAB4C3]">
                        <span>Maintenance Mode</span>
                        <span className={`font-semibold ${settings.maintenanceMode ? 'text-amber-400' : 'text-[#00E676]'}`}>
                          {settings.maintenanceMode ? 'Enabled' : 'Disabled'}
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-[#AAB4C3]">
                        <span>Publishing Engine</span>
                        <span className={`font-semibold ${settings.publishingEnabled ? 'text-[#00E676]' : 'text-rose-400'}`}>
                          {settings.publishingEnabled ? 'Enabled' : 'Disabled'}
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-[#AAB4C3]">
                        <span>Ad Network</span>
                        <span className={`font-semibold ${settings.adsEnabled ? 'text-[#00E676]' : 'text-[#AAB4C3]'}`}>
                          {settings.adsEnabled ? 'Active' : 'Muted'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* LINKS MANAGEMENT TAB */}
              {activeTab === 'links' && (
                <div className="flex flex-col gap-2.5">
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-3 text-[#AAB4C3]" />
                    <input
                      type="text"
                      value={linkSearch}
                      onChange={(e) => setLinkSearch(e.target.value)}
                      placeholder="Search links..."
                      className="w-full bg-[#121824] border border-white/[0.08] rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-[#AAB4C3]/40 focus:outline-none focus:border-[#2196F3]"
                    />
                  </div>

                  <div className="flex flex-col gap-2">
                    {filteredLinks.map((link) => (
                      <div
                        key={link.id}
                        className="bg-[#121824] border border-white/[0.06] rounded-2xl p-3 flex flex-col gap-2"
                      >
                        <div className="flex items-center justify-between">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase ${
                              link.platform === 'whatsapp'
                                ? 'bg-[#00E676]/15 text-[#00E676]'
                                : 'bg-[#2196F3]/15 text-[#2196F3]'
                            }`}
                          >
                            {link.platform} • {link.status}
                          </span>
                          <div className="flex items-center gap-2 text-[11px] text-[#AAB4C3]">
                            <span>{link.shareCount} shares</span>
                            <span>•</span>
                            <span>{link.clickCount} clicks</span>
                          </div>
                        </div>

                        <p className="text-white text-xs font-semibold truncate">
                          {link.title}
                        </p>

                        <div className="flex items-center justify-end gap-1.5 pt-1 border-t border-white/[0.04]">
                          <button
                            onClick={() => handleToggleStatus(link)}
                            className="px-2.5 py-1 rounded-lg bg-white/[0.04] hover:bg-white/[0.08] text-[11px] font-medium text-white transition"
                          >
                            {link.status === 'active' ? 'Disable' : 'Enable'}
                          </button>
                          <button
                            onClick={() => handleDelete(link)}
                            className="px-2.5 py-1 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 text-[11px] font-medium transition"
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* REPORTS TAB */}
              {activeTab === 'reports' && (
                <div className="flex flex-col gap-2.5">
                  <div className="flex items-center justify-between text-xs text-[#AAB4C3] px-1">
                    <span>Recent Reports</span>
                    <button
                      onClick={loadAdminData}
                      className="flex items-center gap-1 hover:text-white"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Refresh</span>
                    </button>
                  </div>

                  {reports.length === 0 ? (
                    <div className="py-12 text-center text-xs text-[#AAB4C3]">
                      No reports found.
                    </div>
                  ) : (
                    reports.map((report) => (
                      <div
                        key={report.id}
                        className="bg-[#121824] border border-white/[0.06] rounded-2xl p-3 flex flex-col gap-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/15 text-amber-400">
                            {report.reason}
                          </span>
                          <span className="text-[10px] text-[#AAB4C3] capitalize">
                            Status: {report.status}
                          </span>
                        </div>

                        <p className="text-white text-xs font-semibold truncate">
                          {report.linkTitle}
                        </p>

                        {report.details && (
                          <p className="text-[11px] text-[#AAB4C3] bg-black/20 p-2 rounded-lg">
                            {report.details}
                          </p>
                        )}

                        <div className="flex items-center justify-end gap-1.5 pt-1 border-t border-white/[0.04]">
                          <button
                            onClick={() => handleResolveReport(report.id, 'dismissed')}
                            className="px-2.5 py-1 rounded-lg bg-white/[0.04] text-[11px] text-[#AAB4C3] hover:text-white"
                          >
                            Dismiss
                          </button>
                          <button
                            onClick={() => handleResolveReport(report.id, 'resolved')}
                            className="px-2.5 py-1 rounded-lg bg-[#00E676]/15 text-[#00E676] text-[11px] font-semibold"
                          >
                            Resolve
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* SYSTEM CONTROLS TAB */}
              {activeTab === 'settings' && (
                <div className="flex flex-col gap-3 py-1">
                  <div className="bg-[#121824] border border-white/[0.06] rounded-2xl p-4 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-semibold text-white block">
                        Advertisements
                      </span>
                      <span className="text-[11px] text-[#AAB4C3]">
                        Show partner sponsored banners in feed
                      </span>
                    </div>
                    <button
                      onClick={() => handleToggleSetting('adsEnabled')}
                      className="tap-bounce text-[#2196F3]"
                    >
                      {settings.adsEnabled ? (
                        <ToggleRight className="w-8 h-8 text-[#00E676]" />
                      ) : (
                        <ToggleLeft className="w-8 h-8 text-[#AAB4C3]" />
                      )}
                    </button>
                  </div>

                  <div className="bg-[#121824] border border-white/[0.06] rounded-2xl p-4 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-semibold text-white block">
                        Allow Link Publishing
                      </span>
                      <span className="text-[11px] text-[#AAB4C3]">
                        Permit community visitors to submit links
                      </span>
                    </div>
                    <button
                      onClick={() => handleToggleSetting('publishingEnabled')}
                      className="tap-bounce text-[#2196F3]"
                    >
                      {settings.publishingEnabled ? (
                        <ToggleRight className="w-8 h-8 text-[#00E676]" />
                      ) : (
                        <ToggleLeft className="w-8 h-8 text-[#AAB4C3]" />
                      )}
                    </button>
                  </div>

                  <div className="bg-[#121824] border border-white/[0.06] rounded-2xl p-4 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-semibold text-white block">
                        Maintenance Mode
                      </span>
                      <span className="text-[11px] text-[#AAB4C3]">
                        Temporarily suspend visitor interactions
                      </span>
                    </div>
                    <button
                      onClick={() => handleToggleSetting('maintenanceMode')}
                      className="tap-bounce text-[#2196F3]"
                    >
                      {settings.maintenanceMode ? (
                        <ToggleRight className="w-8 h-8 text-amber-500" />
                      ) : (
                        <ToggleLeft className="w-8 h-8 text-[#AAB4C3]" />
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
