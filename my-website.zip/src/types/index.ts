export type PlatformType = 'whatsapp' | 'telegram';
export type LinkKind = 'group' | 'channel' | 'community';

export interface LinkItem {
  id: string;
  platform: PlatformType;
  linkType: LinkKind;
  title: string;
  description?: string;
  url: string;
  category: string;
  publisherUid: string;
  createdAt: number;
  updatedAt?: number;
  shareCount: number;
  clickCount: number;
  status: 'active' | 'disabled' | 'flagged';
}

export interface ShareRecord {
  id: string;
  linkId: string;
  uid: string;
  timestamp: number;
  platform: 'whatsapp' | 'telegram' | 'native' | 'copy';
}

export type ReportReason =
  | 'Invalid Link'
  | 'Spam'
  | 'Scam'
  | 'Misleading'
  | 'Inappropriate'
  | 'Other';

export interface ReportItem {
  id: string;
  linkId: string;
  linkTitle: string;
  reportedBy: string;
  reason: ReportReason;
  details?: string;
  createdAt: number;
  status: 'pending' | 'resolved' | 'dismissed';
}

export interface AppSettings {
  adsEnabled: boolean;
  publishingEnabled: boolean;
  maintenanceMode: boolean;
}

export interface UserActivity {
  id: string;
  type: 'publish' | 'share' | 'open';
  linkId: string;
  linkTitle: string;
  platform: PlatformType;
  timestamp: number;
}
