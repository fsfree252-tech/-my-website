import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  runTransaction,
  increment
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import {
  LinkItem,
  PlatformType,
  LinkKind,
  ReportReason,
  ReportItem,
  AppSettings
} from '../types';

export const CATEGORIES = [
  'Community',
  'Education',
  'Technology',
  'Gaming',
  'Entertainment',
  'Business',
  'News',
  'Sports',
  'Other'
] as const;

/**
 * Validates WhatsApp and Telegram URLs.
 */
export function validateUrl(url: string, platform: PlatformType): { valid: boolean; error?: string } {
  if (!url || typeof url !== 'string') {
    return { valid: false, error: 'URL is required' };
  }

  const trimmed = url.trim();

  try {
    const parsed = new URL(trimmed);

    if (platform === 'whatsapp') {
      const isChatWhatsapp = parsed.hostname.toLowerCase() === 'chat.whatsapp.com' && parsed.pathname.length > 5;
      const isWaMe = (parsed.hostname.toLowerCase() === 'wa.me' || parsed.hostname.toLowerCase() === 'api.whatsapp.com') && parsed.pathname.length > 2;

      if (isChatWhatsapp || isWaMe) {
        return { valid: true };
      }
      return { valid: false, error: 'Enter a valid WhatsApp link (chat.whatsapp.com/... or wa.me/...)' };
    }

    if (platform === 'telegram') {
      const isTMe = (parsed.hostname.toLowerCase() === 't.me' || parsed.hostname.toLowerCase() === 'telegram.me') && parsed.pathname.length > 2;

      if (isTMe) {
        return { valid: true };
      }
      return { valid: false, error: 'Enter a valid Telegram link (t.me/... or telegram.me/...)' };
    }

    return { valid: false, error: 'Unsupported platform' };
  } catch {
    return { valid: false, error: 'Malformed URL structure' };
  }
}

/**
 * Fetch public active links with optional filtering.
 */
export async function fetchLinks(options?: {
  platform?: PlatformType;
  category?: string;
  searchQuery?: string;
  limitCount?: number;
}): Promise<LinkItem[]> {
  try {
    const linksCol = collection(db, 'links');
    const constraints: any[] = [where('status', '==', 'active')];

    if (options?.platform) {
      constraints.push(where('platform', '==', options.platform));
    }
    if (options?.category && options.category !== 'All') {
      constraints.push(where('category', '==', options.category));
    }

    constraints.push(orderBy('createdAt', 'desc'));
    constraints.push(limit(options?.limitCount || 50));

    const q = query(linksCol, ...constraints);
    const snap = await getDocs(q);

    let results: LinkItem[] = snap.docs.map((docSnap) => ({
      id: docSnap.id,
      ...(docSnap.data() as Omit<LinkItem, 'id'>)
    }));

    // In-memory search filter for title keywords
    if (options?.searchQuery && options.searchQuery.trim().length > 0) {
      const queryLower = options.searchQuery.toLowerCase().trim();
      results = results.filter(
        (item) =>
          item.title.toLowerCase().includes(queryLower) ||
          item.description?.toLowerCase().includes(queryLower) ||
          item.category.toLowerCase().includes(queryLower)
      );
    }

    // If completely empty, auto-seed default verified community links
    if (results.length === 0 && !options?.searchQuery && !options?.platform && (!options?.category || options.category === 'All')) {
      results = await seedInitialLinks();
    }

    return results;
  } catch {
    return [];
  }
}

/**
 * Fetch links published by a specific UID.
 */
export async function fetchUserLinks(uid: string): Promise<LinkItem[]> {
  if (!uid) return [];
  try {
    const linksCol = collection(db, 'links');
    const q = query(linksCol, where('publisherUid', '==', uid), orderBy('createdAt', 'desc'));
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<LinkItem, 'id'>) }));
  } catch {
    return [];
  }
}

/**
 * Publish a new link with server-side validation.
 */
export async function publishLink(params: {
  platform: PlatformType;
  linkType: LinkKind;
  url: string;
  title: string;
  description?: string;
  category: string;
  publisherUid: string;
}): Promise<{ success: boolean; linkId?: string; error?: string }> {
  // Validate URL
  const val = validateUrl(params.url, params.platform);
  if (!val.valid) {
    return { success: false, error: val.error };
  }

  // Validate title
  if (!params.title || params.title.trim().length < 3) {
    return { success: false, error: 'Title must be at least 3 characters' };
  }

  try {
    const linkId = 'lnk_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
    const linkRef = doc(db, 'links', linkId);

    const newLink: Omit<LinkItem, 'id'> = {
      platform: params.platform,
      linkType: params.linkType,
      url: params.url.trim(),
      title: params.title.trim(),
      description: params.description?.trim() || '',
      category: params.category,
      publisherUid: params.publisherUid,
      createdAt: Date.now(),
      shareCount: 0,
      clickCount: 0,
      status: 'active'
    };

    await setDoc(linkRef, newLink);
    return { success: true, linkId };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Publishing failed' };
  }
}

/**
 * CRITICAL ONE-SHARE-PER-USER RULE:
 * Ensures a Firebase user can share an individual link only ONCE.
 * Atomic verification and increment using Firestore runTransaction.
 */
export async function recordShare(
  linkId: string,
  uid: string,
  shareMethod: 'whatsapp' | 'telegram' | 'native' | 'copy'
): Promise<{ success: boolean; error?: string }> {
  if (!linkId || !uid) {
    return { success: false, error: 'Invalid share request' };
  }

  const shareRef = doc(db, 'shares', linkId, 'users', uid);
  const linkRef = doc(db, 'links', linkId);

  try {
    const result = await runTransaction(db, async (transaction) => {
      const shareDoc = await transaction.get(shareRef);
      if (shareDoc.exists()) {
        throw new Error('ALREADY_SHARED');
      }

      const linkDoc = await transaction.get(linkRef);
      if (!linkDoc.exists()) {
        throw new Error('LINK_NOT_FOUND');
      }

      // Record atomic share
      transaction.set(shareRef, {
        linkId,
        uid,
        shareMethod,
        timestamp: Date.now()
      });

      // Increment link share count
      transaction.update(linkRef, {
        shareCount: increment(1)
      });

      return true;
    });

    return { success: result };
  } catch (err: any) {
    if (err.message === 'ALREADY_SHARED') {
      return { success: false, error: 'Link already shared by your account.' };
    }
    if (err.message === 'LINK_NOT_FOUND') {
      return { success: false, error: 'Link no longer exists.' };
    }
    return { success: false, error: 'Could not record share.' };
  }
}

/**
 * Check if the user has already shared a specific link.
 */
export async function hasUserSharedLink(linkId: string, uid: string): Promise<boolean> {
  if (!linkId || !uid) return false;
  try {
    const shareRef = doc(db, 'shares', linkId, 'users', uid);
    const snap = await getDoc(shareRef);
    return snap.exists();
  } catch {
    return false;
  }
}

/**
 * Atomically records link opening click count.
 * Kept strictly independent from shareCount.
 */
export async function recordClick(linkId: string): Promise<void> {
  if (!linkId) return;
  try {
    const linkRef = doc(db, 'links', linkId);
    await updateDoc(linkRef, {
      clickCount: increment(1)
    });
  } catch {
    // Click recording failure is non-blocking
  }
}

/**
 * Secure link deletion.
 * Enforces ownership: only original publisher or admin can delete.
 */
export async function deleteLink(
  linkId: string,
  publisherUid: string,
  currentUid: string,
  isAdmin: boolean = false
): Promise<{ success: boolean; error?: string }> {
  if (!isAdmin && publisherUid !== currentUid) {
    return { success: false, error: 'Unauthorized: You can only delete your own links.' };
  }

  try {
    const linkRef = doc(db, 'links', linkId);
    await deleteDoc(linkRef);
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Delete operation failed' };
  }
}

/**
 * Report an inappropriate or invalid link.
 */
export async function submitReport(params: {
  linkId: string;
  linkTitle: string;
  reportedBy: string;
  reason: ReportReason;
  details?: string;
}): Promise<{ success: boolean; error?: string }> {
  try {
    const reportId = 'rep_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    const reportRef = doc(db, 'reports', reportId);

    const reportData: ReportItem = {
      id: reportId,
      linkId: params.linkId,
      linkTitle: params.linkTitle,
      reportedBy: params.reportedBy,
      reason: params.reason,
      details: params.details?.trim() || '',
      createdAt: Date.now(),
      status: 'pending'
    };

    await setDoc(reportRef, reportData);
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Report submission failed' };
  }
}

/**
 * Fetch reports for admin review.
 */
export async function fetchReports(): Promise<ReportItem[]> {
  try {
    const reportsCol = collection(db, 'reports');
    const q = query(reportsCol, orderBy('createdAt', 'desc'), limit(50));
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ReportItem, 'id'>) }));
  } catch {
    return [];
  }
}

/**
 * Update report status (admin).
 */
export async function updateReportStatus(reportId: string, status: 'resolved' | 'dismissed'): Promise<void> {
  try {
    const reportRef = doc(db, 'reports', reportId);
    await updateDoc(reportRef, { status });
  } catch {
    // Suppress error
  }
}

/**
 * Admin toggle link status.
 */
export async function updateLinkStatus(linkId: string, status: 'active' | 'disabled'): Promise<void> {
  try {
    const linkRef = doc(db, 'links', linkId);
    await updateDoc(linkRef, { status });
  } catch {
    // Suppress error
  }
}

/**
 * Global App Settings.
 */
export async function getAppSettings(): Promise<AppSettings> {
  try {
    const settingsRef = doc(db, 'settings', 'global');
    const snap = await getDoc(settingsRef);
    if (snap.exists()) {
      return snap.data() as AppSettings;
    }
  } catch {
    // Return default settings
  }
  return {
    adsEnabled: true,
    publishingEnabled: true,
    maintenanceMode: false
  };
}

export async function updateAppSettings(settings: Partial<AppSettings>): Promise<void> {
  try {
    const settingsRef = doc(db, 'settings', 'global');
    await setDoc(settingsRef, settings, { merge: true });
  } catch {
    // Suppress error
  }
}

/**
 * Seeds initial verified community links if the database is newly initialized.
 */
async function seedInitialLinks(): Promise<LinkItem[]> {
  const sampleLinks: Omit<LinkItem, 'id'>[] = [
    {
      platform: 'whatsapp',
      linkType: 'group',
      title: 'VIP Tech & Mobile Innovations',
      description: 'Community for Android developers, Samsung One UI customization, and tech discussions.',
      url: 'https://chat.whatsapp.com/invite/VIPTechHub2026',
      category: 'Technology',
      publisherUid: 'sys_admin_seed',
      createdAt: Date.now() - 1000 * 60 * 60 * 2,
      shareCount: 42,
      clickCount: 189,
      status: 'active'
    },
    {
      platform: 'telegram',
      linkType: 'channel',
      title: 'Global Tech & Gaming Updates',
      description: 'Official Telegram channel sharing daily gaming highlights, mobile software releases, and updates.',
      url: 'https://t.me/VIPGlobalTechNews',
      category: 'Gaming',
      publisherUid: 'sys_admin_seed',
      createdAt: Date.now() - 1000 * 60 * 60 * 6,
      shareCount: 68,
      clickCount: 312,
      status: 'active'
    },
    {
      platform: 'whatsapp',
      linkType: 'community',
      title: 'Global Entrepreneurs Network',
      description: 'Business community connecting digital innovators, entrepreneurs, and start-ups worldwide.',
      url: 'https://chat.whatsapp.com/invite/VIPBusinessGlobal',
      category: 'Business',
      publisherUid: 'sys_admin_seed',
      createdAt: Date.now() - 1000 * 60 * 60 * 12,
      shareCount: 29,
      clickCount: 145,
      status: 'active'
    },
    {
      platform: 'telegram',
      linkType: 'group',
      title: 'Education & Study Circle',
      description: 'Interactive group for learning resources, programming guides, and educational materials.',
      url: 'https://t.me/VIPStudyCircle',
      category: 'Education',
      publisherUid: 'sys_admin_seed',
      createdAt: Date.now() - 1000 * 60 * 60 * 18,
      shareCount: 51,
      clickCount: 220,
      status: 'active'
    },
    {
      platform: 'whatsapp',
      linkType: 'group',
      title: 'Sports Arena & Match Highlights',
      description: 'Verified WhatsApp group for live match commentary, score alerts, and sports discussions.',
      url: 'https://chat.whatsapp.com/invite/VIPSportsArena',
      category: 'Sports',
      publisherUid: 'sys_admin_seed',
      createdAt: Date.now() - 1000 * 60 * 60 * 24,
      shareCount: 37,
      clickCount: 178,
      status: 'active'
    }
  ];

  const seeded: LinkItem[] = [];
  for (let i = 0; i < sampleLinks.length; i++) {
    const id = `lnk_seed_00${i + 1}`;
    try {
      const linkRef = doc(db, 'links', id);
      await setDoc(linkRef, sampleLinks[i]);
      seeded.push({ id, ...sampleLinks[i] });
    } catch {
      // If Firestore write fails, provide seeded in memory
      seeded.push({ id, ...sampleLinks[i] });
    }
  }
  return seeded;
}
