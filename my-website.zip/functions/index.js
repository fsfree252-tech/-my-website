const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();

/**
 * Cloud Function to record share atomically.
 * Enforces the CRITICAL ONE-SHARE-PER-USER RULE on the backend.
 */
exports.recordShare = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError(
      "unauthenticated",
      "User must be authenticated anonymously or with credentials."
    );
  }

  const uid = context.auth.uid;
  const { linkId, shareMethod } = data;

  if (!linkId) {
    throw new functions.https.HttpsError(
      "invalid-argument",
      "The function must be called with a valid linkId."
    );
  }

  const shareRef = db.doc(`shares/${linkId}/users/${uid}`);
  const linkRef = db.doc(`links/${linkId}`);

  return db.runTransaction(async (transaction) => {
    const shareDoc = await transaction.get(shareRef);
    if (shareDoc.exists) {
      throw new functions.https.HttpsError(
        "already-exists",
        "Link already shared by your account."
      );
    }

    const linkDoc = await transaction.get(linkRef);
    if (!linkDoc.exists) {
      throw new functions.https.HttpsError(
        "not-found",
        "The requested link does not exist."
      );
    }

    // Atomic write of the share record
    transaction.set(shareRef, {
      uid,
      linkId,
      shareMethod: shareMethod || "native",
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });

    // Atomic increment of share count
    transaction.update(linkRef, {
      shareCount: admin.firestore.FieldValue.increment(1)
    });

    return { success: true };
  });
});

/**
 * Cloud Function to validate and publish community links.
 */
exports.publishLink = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Authentication required");
  }

  const uid = context.auth.uid;
  const { platform, linkType, url, title, description, category } = data;

  if (!url || !title || !platform || !category) {
    throw new functions.https.HttpsError("invalid-argument", "Missing required fields");
  }

  // Server-side URL format verification
  try {
    const parsed = new URL(url);
    if (platform === "whatsapp") {
      const isChat = parsed.hostname.toLowerCase() === "chat.whatsapp.com";
      const isWa = parsed.hostname.toLowerCase() === "wa.me";
      if (!isChat && !isWa) {
        throw new functions.https.HttpsError("invalid-argument", "Unsupported WhatsApp URL");
      }
    } else if (platform === "telegram") {
      const isTme = parsed.hostname.toLowerCase() === "t.me" || parsed.hostname.toLowerCase() === "telegram.me";
      if (!isTme) {
        throw new functions.https.HttpsError("invalid-argument", "Unsupported Telegram URL");
      }
    }
  } catch (e) {
    throw new functions.https.HttpsError("invalid-argument", "Malformed link URL");
  }

  const linkId = "lnk_" + Date.now() + "_" + Math.random().toString(36).substring(2, 7);
  const linkRef = db.collection("links").doc(linkId);

  await linkRef.set({
    platform,
    linkType: linkType || "group",
    url: url.trim(),
    title: title.trim(),
    description: description ? description.trim() : "",
    category,
    publisherUid: uid,
    createdAt: Date.now(),
    shareCount: 0,
    clickCount: 0,
    status: "active"
  });

  return { success: true, linkId };
});
